"""MyFlix identities within one Kodi installation, with legacy state migration."""
import os,uuid,shutil
import core

def registry(base):
    path=os.path.join(base,'profiles.json')
    data=core.load(path,{})
    if not data.get('profiles'):
        data={'active':'default','profiles':[{'id':'default','name':'My Profile'}]}
        core.save(path,data)
    return data

def directory(base):
    data=registry(base)
    person=next((p for p in data['profiles'] if p['id']==data['active']),data['profiles'][0])
    path=os.path.join(base,'profiles',person['id'])
    os.makedirs(path,exist_ok=True)
    if person['id']=='default':
        for name in ['favorites','history','preferences','watched']:
            old=os.path.join(base,name+'.json');new=os.path.join(path,name+'.json')
            if os.path.isfile(old) and not os.path.exists(new):shutil.copy2(old,new)
    return path

def save(base,data):core.save(os.path.join(base,'profiles.json'),data)
def create(base,name):
    data=registry(base);person={'id':uuid.uuid4().hex,'name':name};data['profiles'].append(person);save(base,data);return person
