"""Kodi dialog for a cancellable download and its completed state."""
from threading import Event, Thread
import time

import xbmc
import xbmcgui


class DownloadProgress(xbmcgui.WindowXMLDialog):
    def run(self, title, transfer, current):
        self.title = title
        self.transfer = transfer
        self.current = current
        self.cancelled = Event()
        self.finished = Event()
        self.monitor = xbmc.Monitor()
        self.error = None
        self.result = False
        self.worker = None
        self.last_update = 0
        try:
            self.doModal()
        finally:
            self.cancelled.set()
            if self.worker is not None:
                self.worker.join()
        if self.error is not None:
            raise self.error
        return self.result

    def onInit(self):
        self.getControl(101).setLabel(self.title)
        self.getControl(103).setLabel('Connecting to source…')
        self.setFocusId(104)
        self.worker = Thread(target=self._download, name='MyFlixDownload')
        self.worker.start()

    def onClick(self, control_id):
        if control_id == 104:
            self._dismiss()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self._dismiss()

    def _dismiss(self):
        if self.finished.is_set():
            self.close()
        else:
            self.cancelled.set()
            self.getControl(104).setLabel('Cancelling…')

    def _progress(self, received, total):
        if self.cancelled.is_set() or self.monitor.abortRequested() or not self.current():
            return False
        now = time.monotonic()
        if now - self.last_update >= .2 or (total and received >= total):
            self.last_update = now
            if total:
                percent = min(99, received * 100 // total)
                self.getControl(102).setPercent(percent)
                detail = f'{percent}% · {received / 1048576:,.1f} of {total / 1048576:,.1f} MB'
                if received >= total:
                    detail += ' · Verifying file'
            else:
                detail = f'{received / 1048576:,.1f} MB downloaded · Total size unavailable'
            self.getControl(103).setLabel(detail)
        return True

    def _download(self):
        try:
            self.result = self.transfer(self._progress)
            if self.result:
                self.getControl(102).setPercent(100)
                self.getControl(100).setLabel('Download successful')
                status = '100% · Ready in MyFlix Downloads'
                if not self.result['audio_verified']:
                    status = '100% · Saved · Audio could not be verified'
                self.getControl(103).setLabel(status)
                self.finished.set()
                self.getControl(104).setLabel('Finished')
                return
        except Exception as exc:
            self.error = exc
        self.close()
