"""Inspect embedded audio track metadata without loading the video payload."""

MP4_MEDIA = {b'moov', b'trak', b'mdia'}
MATROSKA_MEDIA = {0x18538067, 0x1654AE6B, 0xAE}


def mp4_audio(read, end):
    def walk(begin, limit, level):
        position = begin
        while position + 8 <= limit:
            header = read(position, 8)
            size, kind = int.from_bytes(header[:4], 'big'), header[4:]
            start = position + 8
            if size == 1:
                size = int.from_bytes(read(start, 8), 'big')
                start += 8
            stop = position + size if size else limit
            if not start <= stop <= limit:
                raise ValueError('Invalid MP4 box length')
            if kind == b'hdlr' and level == 3 and stop - start >= 12:
                yield read(start + 8, 4) == b'soun'
            if kind in MP4_MEDIA and level < 3:
                yield from walk(start, stop, level + 1)
            position = stop
    tracks = list(walk(0, end, 0))
    return any(tracks) if tracks else None


def matroska_audio(read, end):
    def vint(position, identifier=False):
        first = read(position, 1)[0]
        width = 9 - first.bit_length()
        if width > (4 if identifier else 8):
            raise ValueError('Invalid Matroska field')
        value = int.from_bytes(read(position, width), 'big')
        if not identifier:
            marker = 1 << (width * 7)
            value ^= marker
            if value == marker - 1:
                value = None
        return value, width

    def walk(begin, limit, level):
        position = begin
        while position < limit:
            element, id_width = vint(position, True)
            size, size_width = vint(position + id_width)
            start = position + id_width + size_width
            stop = start + size if size is not None else limit
            if not start <= stop <= limit:
                raise ValueError('Invalid Matroska element length')
            if element == 0x83 and level == 3 and 0 < stop - start <= 8:
                yield int.from_bytes(read(start, stop - start), 'big') == 2
            if element in MATROSKA_MEDIA and level < 3:
                yield from walk(start, stop, level + 1)
            position = stop
    tracks = list(walk(0, end, 0))
    return any(tracks) if tracks else None


def detect(handle, size, extension):
    parser = {'.mp4':mp4_audio, '.m4v':mp4_audio, '.mov':mp4_audio,
              '.mkv':matroska_audio, '.webm':matroska_audio}.get(extension)
    if parser is None:
        return None
    reads = 0

    def read(position, length):
        nonlocal reads
        reads += 1
        if reads > 4096 or position < 0 or position + length > size:
            raise ValueError('Media header cannot be verified')
        if handle.seek(position) != position:
            raise ValueError('Media is not seekable')
        data = handle.readBytes(length)
        if len(data) != length:
            raise ValueError('Media header is incomplete')
        return bytes(data)

    try:
        return parser(read, size)
    except (OSError, RuntimeError, ValueError):
        return None
