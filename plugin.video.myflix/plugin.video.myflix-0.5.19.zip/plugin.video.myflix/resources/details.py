"""Cached metadata through TMDb Helper's public API, without copying account credentials."""
import json,os,sys,time,sqlite3
import xbmcaddon

def api_request(*args):
    import addonpaths
    path=addonpaths.load('plugin.video.themoviedb.helper')
    resources=os.path.join(path,'resources')
    if resources not in sys.path:sys.path.insert(0,resources)
    from tmdbhelper.lib.api.tmdb.api import TMDbAPI
    return TMDbAPI().get_response_json(*args) or {}

def request(base,*args):
    os.makedirs(base,exist_ok=True);path=os.path.join(base,'metadata.sqlite');key='/'.join(map(str,args))
    with sqlite3.connect(path,timeout=15) as db:
        db.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, data TEXT, expires REAL)')
        row=db.execute('SELECT data,expires FROM metadata WHERE key=?',(key,)).fetchone()
        if row and row[1]>time.time():return json.loads(row[0])
    result=api_request(*args)
    if result:
        with sqlite3.connect(path,timeout=15) as db:db.execute('INSERT OR REPLACE INTO metadata VALUES (?,?,?)',(key,json.dumps(result),time.time()+86400))
    return result

def certification(base,item):
    typ='tv' if item.get('type') in ('tv','season','episode') else 'movie'
    identifier=item.get('series_tmdb') or item.get('tmdb')
    if not str(identifier).isdigit():return ''
    data=request(base,typ,identifier,'content_ratings' if typ=='tv' else 'release_dates')
    us=next((r for r in data.get('results',[]) if r.get('iso_3166_1')=='US'),{})
    if typ=='tv':return us.get('rating','')
    values=[]
    for release in us.get('release_dates',[]):
        rating=release.get('certification','')
        if rating and rating not in values:values.append(rating)
    return ' / '.join(values)

def image(value):return 'https://image.tmdb.org/t/p/w780'+value if value else ''

def show(base,identifier):
    data=request(base,'tv',identifier)
    if not data:return {}
    return {'type':'tv','tmdb':str(identifier),'title':data.get('name',''),'plot':data.get('overview',''),'path':'',
            'art':{'poster':image(data.get('poster_path')),'thumb':image(data.get('poster_path')),'fanart':image(data.get('backdrop_path'))},'seasons':data.get('seasons',[])}
