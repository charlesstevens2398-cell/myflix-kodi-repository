"""Merged source selection and a real Kodi plugin playback handoff."""
import os,time
import xbmc,xbmcaddon,xbmcgui
import sourcejobs
WORKER=os.path.join(os.path.dirname(__file__),'sourceworker.py')

def launch(token):
    xbmc.executebuiltin('RunScript("'+WORKER+'",'+token+')')

def wait(base,tokens,title,current,log,timeout):
    monitor=xbmc.Monitor();progress=xbmcgui.DialogProgress();progress.create(title,'Starting providers…')
    deadline=time.monotonic()+timeout
    try:
        while True:
            jobs=[sourcejobs.read(base,t) for t in tokens]
            if progress.iscanceled() or monitor.abortRequested() or not current():
                for token in tokens:sourcejobs.update(base,token,status='cancelled')
                return None
            if any(j and j['status']=='cancelled' for j in jobs):
                for token in tokens:sourcejobs.update(base,token,status='cancelled')
                return None
            jobs=[j or dict(provider='Unavailable provider',status='error',operation='collect',error='Source request expired or disappeared') for j in jobs]
            finished=sum(j['status'] in ('done','error') for j in jobs)
            progress.update(int(100*finished/max(1,len(tokens))), '\n'.join(
                j['provider']+': '+(str(len(j.get('sources',[])))+' sources' if j['status']=='done' and j['operation']=='collect' else j['status']) for j in jobs if j))
            if finished==len(tokens):return jobs
            if time.monotonic()>=deadline:
                for token,job in zip(tokens,jobs):
                    if job and job['status'] not in ('done','error','cancelled'):
                        sourcejobs.update(base,token,status='cancelled')
                        log('WARNING',job['provider']+' source request timed out')
                xbmcgui.Dialog().ok('Source search timed out','Not all providers have finished. The incomplete source list will not open. Try the search again or use Umbrella directly. Details are in MyFlix Log.')
                return None
            monitor.waitForAbort(.2)
    finally:progress.close()

def choose(base,profile,item,current,log,download=False):
    tokens=[];startup_errors=[]
    for name,addon in sourcejobs.PROVIDERS.items():
        if xbmc.getCondVisibility('System.HasAddon('+addon+')'):
            token=None
            try:
                account=xbmcaddon.Addon(addon)
                key={'Umbrella':'realdebridtoken','POV':'rd.token','Seren':'rd.auth'}[name]
                if not account.getSetting(key):log('WARNING',name+' has no Real-Debrid account linked. Link it once for all MyFlix profiles.')
                token=sourcejobs.create(base,profile,item,name);tokens.append(token);launch(token)
            except Exception as exc:
                error=sourcejobs.safe_label(exc)
                log('ERROR','Could not start '+name+' source search',error)
                if token:sourcejobs.update(base,token,status='error',error=error)
                else:startup_errors.append(dict(provider=name,status='error',error=error))
    if not tokens:
        xbmcgui.Dialog().ok('Playback add-ons needed','Run MyFlix Installer → Install / repair MyFlix to install Umbrella, POV and Seren.');return False
    jobs=wait(base,tokens,'MyFlix · Searching Umbrella + POV + Seren',current,log,300)
    if jobs is None:return None
    merged=sourcejobs.merge([(j['provider'],j.get('sources',[]),j.get('meta',{})) for j in jobs if j and j['status']=='done'])
    if not current():return None
    errors=startup_errors+[j for j in jobs if j and j['status']=='error']
    for job in errors:log('ERROR',job['provider']+' source search failed',job.get('error',''))
    counts={j['provider']:len(j.get('sources',[])) for j in jobs if j and j['status']=='done'}
    for job in jobs:
        if job and job['status']=='done':log('INFO',job['provider']+' search finished: '+str(len(job.get('sources',[])))+' sources',str(job.get('diagnostics',{})))
    log('INFO','Combined source search completed',str(len(merged))+' unique sources; '+str(len(errors))+' provider errors')
    rows=[]
    for source in merged:
        label=source['quality']+' · '+('Cached' if source['cached'] else 'Cache unverified')+' · '+' + '.join(source['providers'])
        if source['size']:label+=' · '+format(source['size'],'.2f')+' GB'
        li=xbmcgui.ListItem(label=label,label2=source['name']);rows.append(li)
    if not download:
        rows.append(xbmcgui.ListItem(label='Open Umbrella’s original player',label2='Use the existing native playback option'))
    rows.append(xbmcgui.ListItem(label='Account Manager',label2='Shared Real-Debrid and Trakt setup'))
    while current():
        choice=xbmcgui.Dialog().select('MyFlix Sources · '+str(len(merged))+' results · '+', '.join(name+': '+str(counts.get(name,0)) for name in sourcejobs.PROVIDERS)+(' · provider errors in MyFlix Log' if errors else ''),rows,useDetails=True)
        if choice<0:return None
        if not download and choice==len(merged):return False
        if choice==len(rows)-1:
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.myflix/?mode=accountmanager)');return None
        selected=merged[choice]
        # Store raw URLs privately; the playback URL contains only this random job ID.
        token=sourcejobs.create(base,profile,item,selected['alternatives'][0]['provider'],'resolve')
        sourcejobs.update(base,token,alternatives=selected['alternatives'])
        log('INFO','Selected combined source',selected['quality']+'; '+' + '.join(selected['providers']))
        return token
    return None

def resolve(base,token,current,log,download=False):
    job=sourcejobs.read(base,token)
    if not job:return None
    for alternative in job.get('alternatives',[]):
        if not current():return None
        attempt=sourcejobs.create(base,job['profile'],job['item'],alternative['provider'],'resolve',alternative['raw'],alternative['meta'])
        launch(attempt)
        results=wait(base,[attempt],'MyFlix · Resolving '+alternative['provider'],current,log,90)
        if results is None:return None
        result=results[0]
        url=result.get('url') if result and result['status']=='done' else None
        if isinstance(url,str) and url.startswith(('https://','http://')):
            log('INFO','Combined source resolved',alternative['provider']);return url
        log('ERROR','Selected source could not be resolved',alternative['provider']+'; '+(result.get('error','No playable URL returned') if result else 'Expired request'))
    if download:
        xbmcgui.Dialog().ok('Download source unavailable','The selected source could not be resolved. Try another source.')
    else:
        xbmcgui.Dialog().ok('Source did not play','The selected source could not be resolved. Try another source or open Umbrella’s original player. Details are in MyFlix Log.')
    return None
