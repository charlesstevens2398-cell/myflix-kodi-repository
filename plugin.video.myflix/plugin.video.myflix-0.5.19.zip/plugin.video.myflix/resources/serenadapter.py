"""Seren-only adapter. Does not alter Umbrella, POV or installed provider files."""
import time,json
import xbmc
import sourcejobs

def serializable(value):
    def convert(item):
        if isinstance(item,(set,frozenset)):return sorted(item)
        raise TypeError('Unsupported Seren metadata: '+type(item).__name__)
    return json.loads(json.dumps(value,default=convert))

def fetch_files(resolver,torrent,item,cancelled=lambda:False):
    """Use torrent info/selectFiles rather than legacy instantAvailability."""
    api=resolver.debrid_module
    added=api.add_magnet(torrent['magnet'])
    if not isinstance(added,dict) or not added.get('id'):
        raise RuntimeError('Seren: Real-Debrid did not accept the selected torrent')
    resolver.torrent_id=added['id'];success=False
    try:
        api.torrent_select(resolver.torrent_id,'all')
        deadline=time.monotonic()+12;monitor=xbmc.Monitor()
        while time.monotonic()<deadline:
            if cancelled() or monitor.abortRequested():raise InterruptedError('Seren resolution cancelled')
            info=api.torrent_info(resolver.torrent_id)
            if isinstance(info,dict) and info.get('status')=='downloaded' and info.get('links'):
                selected=[dict(f) for f in info.get('files',[]) if f.get('selected')]
                links=info['links']
                if len(selected)!=len(links):raise RuntimeError('Seren: torrent files and download links do not match')
                for file,link in zip(selected,links):file['link']=link
                success=True;return selected
            if isinstance(info,dict) and info.get('status') in ('error','magnet_error','virus','dead'):
                raise RuntimeError('Seren: torrent is unavailable')
            if monitor.waitForAbort(.5):raise InterruptedError('Kodi is closing')
        raise RuntimeError('Seren: selected torrent is not ready to stream; choose another link')
    finally:
        if not success:api.delete_torrent(resolver.torrent_id)

def metadata(item):
    value=sourcejobs.prepare_item(item)
    info=dict(value.get('source_meta') or value)
    episode=value.get('type')=='episode'
    info.update(title=value.get('title',''),originaltitle=value.get('title',''),mediatype='episode' if episode else 'movie',
                imdb_id=value.get('imdb',''),tmdb_id=str(value.get('series_tmdb') or value.get('tmdb','')),
                year=str(value.get('year') or ''),aliases=info.get('aliases') or [])
    if episode:
        if not value.get('tvshowtitle'):raise ValueError('Seren episode search needs its series title')
        info.update(tvshowtitle=value['tvshowtitle'],season=int(value['season']),episode=int(value['episode']))
        info['tvshow.year']=str(value.get('show_year') or value.get('year') or '')
    else:info.pop('tvshowtitle',None)
    return dict(info=info,art=value.get('art',{}),is_airing=False,season_count=value.get('season_count',1),
                episode_count=max(1,int(value.get('episode_count') or 1)),show_episode_count=max(1,int(value.get('show_episode_count') or 1)))

def run(job,progress,cancelled):
    from resources.lib.modules.globals import g
    g.init_globals(['plugin://plugin.video.seren/','-1',''],addon_id='plugin.video.seren')
    if job['operation']=='setup':
        from resources.lib.modules.providers.install_manager import ProviderInstallManager
        manager=ProviderInstallManager(silent=True)
        manager.install_package(0,url=job['meta']['archive'])
        if not any(p.get('pack_name')=='a4kScrapers' for p in manager.known_packages):
            raise RuntimeError('Seren provider package was not installed')
        return dict(sources=[],meta={})
    native=job.get('meta') or metadata(job['item'])
    if job['operation']=='resolve':
        from resources.lib.modules.resolver import Resolver
        from resources.lib.modules.resolver.torrent_resolvers.real_debrid import RealDebridResolver
        # Worker-local override; native file/episode selection remains in Seren.
        RealDebridResolver._fetch_source_files=lambda self,torrent,item:fetch_files(self,torrent,item,cancelled)
        url,_=Resolver().resolve_single_source(job['source'],native,silent=True)
        if not isinstance(url,str) or not url.startswith(('https://','http://')):
            raise RuntimeError('Seren returned no playable link for the selected source')
        return {'url':url}
    from resources.lib.modules import getSources
    class Window:
        def __init__(self,*a,**k):pass
        def create(self):pass
        def close(self):pass
        def set_text(self,*a,**k):pass
        def set_property(self,*a,**k):pass
        def set_progress(self,*a,**k):pass
    getSources.SourceWindowAdapter=Window
    # RD no longer supplies this legacy bulk cache check. Preserve candidates as
    # unverified and check the selected file only when the user chooses it.
    getSources.TorrentCacheCheck._realdebrid_worker=lambda *a,**k:None
    g.cancel_playback=lambda:None
    original_abort=g.abort_requested
    g.abort_requested=lambda:cancelled() or original_abort()
    src=getSources.Sources(native);src.preem_enabled=False
    src._check_local_torrent_database=lambda:None
    src._store_torrent_results=lambda *a:None
    src._build_cache_assist=lambda:None
    result=src.get_sources()
    if not isinstance(result,(tuple,list)) or len(result)!=3:raise RuntimeError('Seren did not complete source search')
    sources=[s for s in result[1] if s.get('type')!='adaptive']
    if g.real_debrid_enabled():
        sources.extend(dict(s,debrid_provider='real_debrid',cache_verified=False) for s in result[0])
    return dict(sources=serializable(sources),meta=serializable(result[2]),diagnostics={'returned':len(sources),'unverified':sum(s.get('cache_verified') is False for s in sources)})
