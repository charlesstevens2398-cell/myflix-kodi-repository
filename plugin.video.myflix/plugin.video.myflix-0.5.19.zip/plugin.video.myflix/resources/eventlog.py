"""Bounded diagnostic events; never stores account tokens or full request URLs."""
import datetime,hashlib,os,re,sqlite3
from urllib.parse import urlsplit,parse_qsl,urlencode
COLORS={'ERROR':'FFFF5964','WARNING':'FFFFBE55','INFO':'FF75BFFF'}
SECRET=re.compile(r'(?i)([\"\']?(?:access_token|refresh_token|realdebridtoken|trakt_token|token|authorization|password|secret|api_key|client_secret|rd\.token|rd\.secret|rd\.refresh)[\"\']?\s*[:=]\s*)(?:[\"\'][^\"\']*[\"\']|[^\s,;]+)')
HEADER=re.compile(r'^\d{4}-\d\d-\d\d[ T].*?\b(ERROR|WARNING|INFO|DEBUG|FATAL)\s*[: ]',re.M|re.I)
RELEVANT=re.compile(r'myflix|umbrella|cocoscrapers|themoviedb.helper|tmdbhelper|real.?debrid|plugin.video.pov|\bpov\b|magneto|acctmgr|account.manager',re.I)
def safe_route(match):
    value=match.group(0)
    if not value.startswith('plugin://'):return '[URL hidden]'
    try:
        route=urlsplit(value)
        if not re.fullmatch(r'[a-zA-Z0-9_.]+',route.netloc):return '[URL hidden]'
        allowed={'action','info','tmdb_type','season','episode','select'}
        args=[(key,val) for key,val in parse_qsl(route.query) if key in allowed and re.fullmatch(r'[a-zA-Z0-9_]+',val)]
        return 'plugin://'+route.netloc+'/?'+urlencode(args)
    except Exception:return '[URL hidden]'

def clean(value):
    s=re.sub(r'(?i)(Bearer|Basic)\s+[^\s\"\']+',r'\1 [hidden]',str(value))
    s=SECRET.sub(r'\1[hidden]',s)
    s=re.sub(r'(?:https?|plugin)://[^\s\"\'<>]+',safe_route,s)
    s=re.sub(r'magnet:[^\s\"\'<>]+','[URL hidden]',s)
    s=re.sub(r'(?i)\[/?COLOR[^\]]*\]','',s)
    return s[:6000]

def connect(path):
    os.makedirs(os.path.dirname(path),exist_ok=True)
    db=sqlite3.connect(path,timeout=5)
    db.execute('CREATE TABLE IF NOT EXISTS cleared_events (fingerprint TEXT PRIMARY KEY)')
    db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, time TEXT, level TEXT, source TEXT, message TEXT, detail TEXT, fingerprint TEXT UNIQUE)')
    return db

def add(path,level,source,message,detail='',fingerprint=None):
    with connect(path) as db:
        if fingerprint and db.execute('SELECT 1 FROM cleared_events WHERE fingerprint=?',(fingerprint,)).fetchone():return
        db.execute('INSERT OR IGNORE INTO events (time,level,source,message,detail,fingerprint) VALUES (?,?,?,?,?,?)',
                   (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),level if level in COLORS else 'INFO',clean(source),clean(message),clean(detail),fingerprint))
        db.execute('DELETE FROM events WHERE id NOT IN (SELECT id FROM events ORDER BY id DESC LIMIT 500)')

def rows(path,limit=100):
    with connect(path) as db:
        db.row_factory=sqlite3.Row
        return [dict(r) for r in db.execute('SELECT * FROM events ORDER BY id DESC LIMIT ?', (limit,))]

def get(path,id):
    with connect(path) as db:
        db.row_factory=sqlite3.Row
        row=db.execute('SELECT * FROM events WHERE id=?',(id,)).fetchone()
        return dict(row) if row else None

def ingest(path,kodi_path):
    try:
        with open(kodi_path,'rb') as f:
            f.seek(0,2);length=f.tell();f.seek(max(0,length-131072));text=f.read().decode('utf-8','replace')
    except OSError:return
    matches=list(HEADER.finditer(text))
    for n,m in enumerate(matches):
        level=m.group(1).upper()
        if level not in ('ERROR','FATAL','WARNING'):continue
        block=text[m.start():matches[n+1].start() if n+1<len(matches) else len(text)].strip()
        if not RELEVANT.search(block):continue
        source='Umbrella' if 'umbrella' in block.lower() else 'CocoScrapers' if 'cocoscrapers' in block.lower() else 'TMDb Helper' if re.search('tmdb|themoviedb',block,re.I) else 'POV' if re.search(r'plugin.video.pov|\bpov\b|magneto',block,re.I) else 'Account Manager' if re.search('acctmgr|account.manager',block,re.I) else 'MyFlix'
        lines=block.splitlines();message=lines[0][m.end()-m.start():].strip() or 'Kodi reported an error'
        add(path,'ERROR' if level=='FATAL' else level,source,message,block,hashlib.sha256(block.encode()).hexdigest())


def clear(path,kodi_path):
    # Ingest first, then suppress those fingerprints so Refresh cannot restore them.
    ingest(path,kodi_path)
    with connect(path) as db:
        db.execute('INSERT OR IGNORE INTO cleared_events SELECT fingerprint FROM events WHERE fingerprint IS NOT NULL')
        db.execute('DELETE FROM events')
