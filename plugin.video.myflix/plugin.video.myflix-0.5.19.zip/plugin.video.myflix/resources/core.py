"""Personal state and filtering, independent of Kodi for testing."""
import json
import os
import re
import tempfile
import time


def load(path, default):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.myflix-', dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def key(item):
    # Episode identities include their series and episode numbers.
    return '{}:{}:{}:{}'.format(item.get('type', 'movie'),
        item.get('tmdb') or item.get('imdb') or item.get('path', ''),
        item.get('season', ''), item.get('episode', ''))


def allowed(item, kids=False, level='PG'):
    if not kids:
        return True
    rating = str(item.get('mpaa', '')).upper()
    matches = re.findall(r'(?<![A-Z0-9])(TV-Y7-FV|TV-Y7|TV-Y|TV-G|TV-PG|TV-14|TV-MA|PG-13|PG|G|R|NC-17)(?![A-Z0-9-])', rating)
    if not matches:
        return False  # Unknown ratings are excluded from Kids browsing.
    safe = {'G', 'TV-Y', 'TV-Y7', 'TV-Y7-FV', 'TV-G'}
    if level in ('PG','PG-13'):
        safe.update(('PG', 'TV-PG'))
    if level=='PG-13':safe.update(('PG-13','TV-14'))
    return all(rating in safe for rating in matches)


def favorite_toggle(path, item):
    records = load(path, [])
    identity = key(item)
    exists = any(key(i) == identity for i in records)
    records = [i for i in records if key(i) != identity]
    if not exists:
        records.insert(0, item)
    save(path, records)
    return not exists


def record_watch(path, item, watched_seconds, position=0, total=0):
    # Selecting, browsing or briefly opening a title never creates history.
    if watched_seconds < 30:
        return False
    record = dict(item)
    record.update(lastwatched=time.time(), position=position, total=total,
                  completed=bool(total and position / total >= 0.9))
    records = [i for i in load(path, []) if key(i) != key(record)]
    save(path, [record] + records[:99])
    return True


def rows(records, kids=False, level='PG'):
    return [i for i in records if allowed(i, kids, level)]


def episode_key(item):
    series=item.get('series_tmdb') or item.get('tmdb','')
    return 'episode-state:{}:{}:{}'.format(series,item.get('season',-1),item.get('episode',-1))


def completed_episodes(history, overrides):
    result={}
    for original in history:
        item=normalize_episode(original)
        if item.get('type')!='episode':continue
        marker=episode_key(item)
        result.setdefault(marker,bool(item.get('completed')))
        if key(item) in overrides:result[marker]=bool(overrides[key(item)])
    for marker,value in overrides.items():
        if marker.startswith('episode-state:'):result[marker]=bool(value)
    return {marker for marker,value in result.items() if value}


def set_episode_watched(overrides,item,value):
    overrides[key(item)]=value
    overrides[episode_key(item)]=value


def watch_status(item, history, overrides=None):
    overrides=overrides or {}
    identity=key(item)
    if item.get('type')=='episode' and episode_key(item) in overrides:
        return 'Watched' if overrides[episode_key(item)] else ''
    if item.get('type') not in ('season','tv') and identity in overrides:
        return 'Watched' if overrides[identity] else ''
    episodes=completed_episodes(history,overrides)
    series=str(item.get('series_tmdb') or item.get('tmdb') or '')
    if item.get('type')=='episode' and episode_key(item) in episodes:return 'Watched'
    if item.get('type')=='season':
        prefix='episode-state:{}:{}:'.format(series,item.get('season'))
        count=sum(marker.startswith(prefix) for marker in episodes)
        total=item.get('episode_count',0)
        if total and count>=total:return 'Watched'
        if count:return str(count)+'/'+str(total)+' episodes watched' if total else str(count)+' episodes watched'
        if not any(marker.startswith(prefix) for marker in overrides) and identity in overrides:
            return 'Watched' if overrides[identity] else ''
        return ''
    if item.get('type')=='tv':
        count=sum(marker.startswith('episode-state:'+series+':') for marker in episodes)
        if count:return str(count)+' episode'+('s' if count!=1 else '')+' watched'
    if any(key(normalize_episode(i))==identity and i.get('completed') for i in history):return 'Watched'
    return ''


def has_rating(item):
    return bool(re.search(r'(?<![A-Z0-9])(TV-Y7-FV|TV-Y7|TV-Y|TV-G|TV-PG|TV-14|TV-MA|PG-13|PG|G|R|NC-17)(?![A-Z0-9-])',str(item.get('mpaa','')).upper()))

def normalize_episode(item):
    record=dict(item)
    if record.get('type') in ('tv','tvshow','season'):return record
    try:episode=int(record.get('season',-1))>=0 and int(record.get('episode',-1))>=0
    except (TypeError,ValueError):episode=False
    if episode:
        record['type']='episode'
        record['series_tmdb']=record.get('series_tmdb') or record.get('tmdb','')
    return record

def recent(records,typ='both'):
    result=[];seen=set()
    for original in records:
        item=normalize_episode(original)
        if item.get('type')=='episode':
            series=item.get('series_tmdb')
            if not series:continue
            item=dict(item,type='tv',tmdb=series,title=item.get('showtitle') or item.get('tvshowtitle') or 'TV Show',season=-1,episode=-1,completed=False)
            art=item.get('art',{});item['art']=dict(art,poster=art.get('tvshow.poster') or art.get('poster',''))
        if typ!='both' and item.get('type')!=typ:continue
        identity=(item.get('type'),item.get('tmdb') or item.get('imdb'))
        if identity in seen:continue
        seen.add(identity);result.append(item)
    return result
