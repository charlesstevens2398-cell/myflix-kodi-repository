"""Expose installed Kodi dependency modules using their addon.xml declarations."""
import os,sys,xml.etree.ElementTree as ET
import xbmcaddon,xbmcvfs

def load(addon_id, factory=None, seen=None):
    factory=factory or xbmcaddon.Addon
    seen=set() if seen is None else seen
    if addon_id in seen:return None
    path=xbmcvfs.translatePath(factory(addon_id).getAddonInfo('path'))
    root=ET.parse(os.path.join(path,'addon.xml')).getroot()
    seen.add(addon_id)
    for dependency in root.findall('./requires/import'):
        name=dependency.get('addon','')
        if not name or name.startswith('xbmc.'):continue
        try:load(name,factory,seen)
        except Exception:
            if dependency.get('optional')!='true':raise
    for extension in root.findall('extension'):
        if extension.get('point')=='xbmc.python.module':
            module=os.path.join(path,extension.get('library','lib'))
            if module not in sys.path:sys.path.insert(0,module)
    return path
