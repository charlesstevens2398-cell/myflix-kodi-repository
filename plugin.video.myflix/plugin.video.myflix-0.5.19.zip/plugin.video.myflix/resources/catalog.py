"""Curated franchise groups and the complete TMDb movie/TV genre catalog."""
MOVIE_GENRES=[('Action','28'),('Adventure','12'),('Animation','16'),('Comedy','35'),('Crime','80'),('Documentary','99'),('Drama','18'),('Family','10751'),('Fantasy','14'),('History','36'),('Horror','27'),('Music','10402'),('Mystery','9648'),('Romance','10749'),('Science Fiction','878'),('TV Movie','10770'),('Thriller','53'),('War','10752'),('Western','37')]
TV_GENRES=[('Action & Adventure','10759'),('Animation','16'),('Comedy','35'),('Crime','80'),('Documentary','99'),('Drama','18'),('Family','10751'),('Kids','10762'),('Mystery','9648'),('News','10763'),('Reality','10764'),('Science Fiction & Fantasy','10765'),('Soap','10766'),('Talk','10767'),('War & Politics','10768'),('Western','37')]
COLLECTIONS=[
 {'id':'marvel','title':'Marvel','children':['avengers','ironman','captainamerica','thor','guardians','antman','blackpanther','deadpool'],'sets':[],'shows':[1403,85271,88396,84958,92782,92783,91363,96467,103540,61889,38472,62126,62127,62285],'plot':'Marvel movie franchises and television shows.'},
 {'id':'dc','title':'DC','children':['batman','superman','wonderwoman','aquaman','suicidesquad'],'sets':[],'shows':[1412,60735,62688,4604,95057,75450,79501,60708,62643,2098],'plot':'DC movie franchises and television shows.'},
 {'id':'fast','title':'Fast & Furious','sets':[9485]},
 {'id':'potter','title':'Harry Potter','sets':[1241]},
 {'id':'divergent','title':'Divergent','sets':[283579]},
 {'id':'hungergames','title':'The Hunger Games','sets':[131635]},
 {'id':'starwars','title':'Star Wars','sets':[10],'shows':[82856,115036,92830,114461,83867]},
 {'id':'toystory','title':'Toy Story','sets':[10194]},
 {'id':'jurassic','title':'Jurassic Park','sets':[328]},
 {'id':'rings','title':'The Lord of the Rings','sets':[119]},
 {'id':'hobbit','title':'The Hobbit','sets':[121938]},
 {'id':'matrix','title':'The Matrix','sets':[2344]},
 {'id':'mission','title':'Mission: Impossible','sets':[87359]},
 {'id':'pirates','title':'Pirates of the Caribbean','sets':[295]},
 {'id':'bond','title':'James Bond','sets':[645]},
 {'id':'backfuture','title':'Back to the Future','sets':[264]},
 {'id':'shrek','title':'Shrek','sets':[2150]},
 {'id':'despicable','title':'Despicable Me','sets':[86066]},
 {'id':'kungfu','title':'Kung Fu Panda','sets':[77816]},
 {'id':'dragon','title':'How to Train Your Dragon','sets':[89137]},
 {'id':'frozen','title':'Frozen','sets':[386382]},
 {'id':'monsters','title':'Monsters, Inc.','sets':[137696]},
 {'id':'cars','title':'Cars','sets':[87118]},
 {'id':'iceage','title':'Ice Age','sets':[8354]},
 {'id':'twilight','title':'Twilight','sets':[33514]},
 {'id':'transformers','title':'Transformers','sets':[8650]},
 {'id':'apes','title':'Planet of the Apes','sets':[173710]},
]
CHILDREN=[
 {'id':'avengers','title':'Avengers','sets':[86311]},
 {'id':'ironman','title':'Iron Man','sets':[131292]},
 {'id':'captainamerica','title':'Captain America','sets':[131295]},
 {'id':'thor','title':'Thor','sets':[131296]},
 {'id':'guardians','title':'Guardians of the Galaxy','sets':[284433]},
 {'id':'antman','title':'Ant-Man','sets':[422834]},
 {'id':'blackpanther','title':'Black Panther','sets':[529892]},
 {'id':'deadpool','title':'Deadpool','sets':[448150]},
 {'id':'batman','title':'Batman','sets':[120794]},
 {'id':'superman','title':'Superman','sets':[8537]},
 {'id':'wonderwoman','title':'Wonder Woman','sets':[468552]},
 {'id':'aquaman','title':'Aquaman','sets':[573693]},
 {'id':'suicidesquad','title':'Suicide Squad','sets':[531242]},
]
def find(identifier):
    item=next((dict(i) for i in COLLECTIONS+CHILDREN if i['id']==identifier),None)
    if item:item.setdefault('plot','Browse '+item['title']+' movies and shows.')
    return item
