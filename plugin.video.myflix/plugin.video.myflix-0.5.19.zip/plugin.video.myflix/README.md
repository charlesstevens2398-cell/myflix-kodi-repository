
Episode source search repair: normalize series title, series ID and show year before Umbrella collection and resolution; refresh native settings and report separate provider source counts and native filtering failures.
