MYFLIX 0.2.0 — FAMILY PROFILES EDITION

INSTALL ON XBOX KODI 21.2
1. Switch back to Estuary before updating.
2. Copy both ZIPs to the USB drive. Do not unzip these installable ZIPs.
3. Kodi > Add-ons > Install from zip file:
   Install plugin.video.myflix-0.2.0.zip FIRST.
   Install skin.myflix-0.2.0.zip SECOND.
4. Restart Kodi. Settings > Interface > Skin > MyFlix.
5. Keep Estuary installed. If MyFlix fails to open correctly, do not confirm
   the skin-change prompt; let Kodi revert to the previous skin.

CREATE MOM / DAD / KIDS
MyFlix > Settings > Create / Manage Profiles opens Kodi's native profile manager.
Create separate profiles with names you choose. Use SEPARATE media info and
SEPARATE media sources. Prefer fresh settings so account authorizations are
not accidentally copied between people. Select MyFlix as the skin in each
new profile, and enable the companion add-on if Kodi has disabled it there.
Enable 'Show login screen on startup' in Kodi Profile Settings.
The new MyFlix login screen displays your actual Kodi profiles, not dummy
Mom/Dad/Kids buttons. Profile switching uses Kodi's native profile loading.

OPTIONAL PROFILE PICTURES
The skin includes these pictures for selection in Kodi's Profile picture dialog:
special://home/addons/skin.myflix/media/myflix-mom.png
special://home/addons/skin.myflix/media/myflix-dad.png
special://home/addons/skin.myflix/media/myflix-kids.png
Custom profile names and pictures are also supported.

PERSONAL FAVORITES
Choose '+ Favorites' on the home/details page, or use a title's context menu
and 'Add to Favorites'. Favorites belong to the current Kodi profile only.
The Favorites tab has separate Movie and Show rows. Saving a series saves
the show, whose seasons/episodes you can then browse. Native episode browsing
also has a '+ / - Favorites' control above the grid.
This MyFlix collection is local; it is independent of shared Trakt watchlists.

RECENTLY WATCHED / CONTINUE WATCHING
The history service records actual video playback, not menu selections.
A minimum 30 seconds of unpaused playback is required before a title is added.
Recently Watched appears only when this profile has recorded watched titles.
Continue Watching appears only when this profile has unfinished played titles.
History and favorites use the active profile's own addon_data folder.
A title is complete at 90% playback. The last 100 watched items are retained.
The service relies on the player's movie/episode metadata (TMDb or IMDb IDs).
Players that omit this metadata may not produce a history entry.
Playback resume ultimately depends on TMDb Helper / Umbrella's resume support.
The skin displays stored progress; it cannot force an add-on to honor resume.

EXISTING TRAKT HISTORY
History is never copied silently into a new profile. In MyFlix Settings,
'Import This Profile's Trakt History' can import the authorized Trakt account's
watched titles after you confirm that account belongs to this person.
Use a separate Trakt account for each person if you want separate cloud history.
If people share one Trakt account, its existing cloud history cannot be separated
by the skin. Local MyFlix history and favorites still remain separate.

HOME / MOVIES / SHOWS / SEARCH
Home: Recommended For the active profile, Continue Watching (if any),
Recently Watched (if any), Trending Movies and Trending Shows.
Suggestions use a recently watched movie or a known series where available.
For a new profile, the recommendation row mixes popular movies and shows.
Movie and Show pages include genre/category rows and horizontal cards.
Search combines movie and show results, using the active profile's Kids filter.
The default artwork is a neutral generated cinema backdrop, not a fake title.
Actual title art and metadata come from your installed TMDb Helper.
Rows show up to 24 items each. Context menu > MyFlix Details opens the
custom title page. TV Play/Episodes opens season/episode browsing.

KIDS PROFILES
While signed into the intended Kids profile, open MyFlix Settings and enable
'Kids Profile'. Set a parent PIN when prompted. A single household parent PIN
is stored as a salted PBKDF2 hash; the plain PIN is not stored.
Rating limits: G / TV-G and younger, or PG / TV-PG and younger.
Unrated titles are excluded from MyFlix browsing in Kids mode.
MyFlix requires the parent PIN for its profile switch and settings flows in
Kids mode. Set/change the PIN from MyFlix Settings.
Use Kodi's native profile/master locks to restrict settings, add-ons and other
ways of leaving the MyFlix interface. MyFlix's filter does not secure every
external add-on or every Kodi entry point. Metadata ratings may be incomplete.
Review available content and account settings before giving Kids access.

ACCOUNT SETUP
Install/configure a working Kodi-21-compatible TMDb Helper separately.
In each profile, configure its maintained Umbrella player definition inside
TMDb Helper and choose it as the default movie/episode player.
Authorize Real-Debrid in Umbrella. Authorize the intended Trakt account in
TMDb Helper / your playback add-on. Avoid running duplicate scrobblers.
MyFlix Settings links directly to the real add-on account dialogs.
No credentials are included in these ZIPs; MyFlix does not scrape sources.

TESTING AND LIMITS
Passed: all XML parses; new control IDs/navigation; Python compilation;
profile-local favorites/history isolation; no history for merely opened
content or less than 30 seconds playback; history deduplication/completion;
Kids rating filtering; real companion routing with stubbed Kodi APIs.
A graphical Kodi runtime could not start in the execution environment, so
these ZIPs have not received a Kodi 21.2 Xbox rendering/playback test.
The design implements the approved direction, but exact runtime appearance
needs an Xbox screenshot and may require another correction.
Kodi's standard account dialogs and some utility dialogs retain their native
Estuary layouts. Profile creation uses Kodi's native profile manager.

CREDITS
Skin based on Team Kodi Estuary (Omega); original licence notices retained.
MyFlix companion source is included in its ZIP.
Artwork: original generated default cinema backdrop; title images are external
metadata artwork loaded by your installed add-ons.
