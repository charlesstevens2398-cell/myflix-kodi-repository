"""Download resolved video files and index completed transfers per profile."""
from contextlib import closing
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
from urllib.parse import quote, unquote, urlsplit
import xbmcvfs
from urllib.request import Request, urlopen

VIDEO_EXTENSIONS = {'.avi', '.m2ts', '.m4v', '.mkv', '.mov', '.mp4', '.mpeg',
                    '.mpg', '.ts', '.webm', '.wmv'}


def open_index(profile):
    os.makedirs(profile, exist_ok=True)
    db = sqlite3.connect(os.path.join(profile, 'downloads.sqlite'))
    db.execute('CREATE TABLE IF NOT EXISTS downloads (id TEXT PRIMARY KEY, path TEXT, item TEXT)')
    return db


def entries(profile):
    with closing(open_index(profile)) as db:
        rows = db.execute('SELECT id, path, item FROM downloads ORDER BY rowid DESC').fetchall()
    return [(token, path, json.loads(item)) for token, path, item in rows if xbmcvfs.exists(path)]


def safe_name(value):
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(value or 'Untitled'))
    value = value[:100].strip(' .') or 'Untitled'
    if re.fullmatch(r'CON|PRN|AUX|NUL|COM[0-9¹²³]|LPT[0-9¹²³]', value.split('.')[0], re.I):
        return '_' + value
    return value


def show_name(item):
    return item.get('showtitle') or item.get('tvshowtitle') or 'Unknown show'


def show_key(item):
    return str(item.get('series_tmdb') or show_name(item))


def episode_label(item):
    return 'S{:02d}E{:02d}'.format(int(item.get('season') or 0), int(item.get('episode') or 0))


class FolderError(OSError):
    """Kodi could not write to the configured download location."""


def child(folder, *parts):
    if '://' in folder:
        path, delimiter, options = folder.partition('|')
        encoded = '/'.join(quote(part, safe='') for part in parts)
        return path.rstrip('/') + '/' + encoded + delimiter + options
    return os.path.join(folder, *parts)


def ensure_directory(path):
    base, delimiter, options = path.partition('|')
    separator = '/' if '://' in base else os.sep
    directory = base.rstrip('/\\') + separator + delimiter + options
    if not xbmcvfs.exists(directory) and not xbmcvfs.mkdirs(directory) and not xbmcvfs.exists(directory):
        raise FolderError('Could not create the download folder')


def publish(partial, destination, name, extension, lock_base, received):
    with closing(sqlite3.connect(os.path.join(lock_base, 'download-lock.sqlite'), timeout=30)) as db:
        db.execute('BEGIN IMMEDIATE')
        for number in range(1, 10000):
            suffix = ' (' + str(number) + ')' if number > 1 else ''
            path = child(destination, name + suffix + extension)
            if xbmcvfs.exists(path):
                continue
            if not xbmcvfs.rename(partial, path):
                if not xbmcvfs.copy(partial, path) or xbmcvfs.Stat(path).st_size() != received:
                    if xbmcvfs.exists(path):
                        xbmcvfs.delete(path)
                    raise FolderError('Could not save the completed download')
            return path
    raise ValueError('Could not choose an available filename.')


def save(profile, folder, item, url, progress, lock_base):
    address, _, options = url.partition('|')
    from urllib.parse import parse_qsl
    request = Request(address, headers=dict(parse_qsl(options)))
    with urlopen(request, timeout=20) as response:
        mime = response.headers.get_content_type()
        name = response.headers.get_filename() or unquote(urlsplit(response.geturl()).path)
        extension = Path(name).suffix.lower()
        if (mime.startswith('text/') or mime in ('application/json', 'application/dash+xml',
                'application/vnd.apple.mpegurl', 'application/x-mpegurl') or
                (extension not in VIDEO_EXTENSIONS and not mime.startswith('video/'))):
            raise ValueError('Choose a direct video file. This source returned a page or stream playlist.')
        if extension not in VIDEO_EXTENSIONS:
            extension = {'video/x-matroska': '.mkv', 'video/webm': '.webm',
                         'video/quicktime': '.mov', 'video/mp2t': '.ts'}.get(mime, '.mp4')
        title = item.get('title') or 'Untitled'
        if item.get('type') == 'episode':
            destination = child(folder, 'TV Shows', safe_name(show_name(item)),
                               'Season {:02d}'.format(int(item.get('season') or 0)))
            name = episode_label(item) + ' - ' + safe_name(title)
        else:
            destination = child(folder, 'Movies')
            year = str(item.get('year') or '')
            name = safe_name(title) + (' (' + year + ')' if re.fullmatch(r'\d{4}', year) else '')
        ensure_directory(destination)
        token = secrets.token_hex(16)
        partial = child(destination, '.myflix-' + token + '.part')
        total = int(response.headers.get('Content-Length') or 0)
        if response.headers.get('Content-Range'):
            raise ValueError('The source returned an incomplete video file.')
        received = 0
        published = None
        try:
            with xbmcvfs.File(partial, 'w') as output:
                while progress(received, total):
                    chunk = response.read(256 * 1024)
                    if not chunk:
                        break
                    if not output.write(bytearray(chunk)):
                        raise FolderError('Could not write to the download folder')
                    received += len(chunk)
                else:
                    return False
            if not received or (total and received != total):
                raise ValueError('The download ended before the complete video was received.')
            if not xbmcvfs.exists(partial) or xbmcvfs.Stat(partial).st_size() != received:
                raise FolderError('Could not verify the downloaded file')
            published = publish(partial, destination, name, extension, lock_base, received)
            with closing(open_index(profile)) as db, db:
                db.execute('INSERT INTO downloads VALUES (?,?,?)',
                           (token, str(published), json.dumps(item, ensure_ascii=False)))
        except Exception:
            if published is not None:
                xbmcvfs.delete(published)
            raise
        finally:
            if xbmcvfs.exists(partial):
                xbmcvfs.delete(partial)
    return True
