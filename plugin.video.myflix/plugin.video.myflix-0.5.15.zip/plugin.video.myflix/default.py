import base64
import json
import os
import hashlib
import secrets
import sqlite3
import sys
from urllib.parse import urlencode, parse_qsl
from itertools import zip_longest
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources'))
import core
import profiles
import eventlog
import catalog
import details
import sourcejobs
import sourcelist
import downloads

BASE = 'plugin://plugin.video.myflix/'
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
PARAMS = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}
WIN = xbmcgui.Window(10000)
REMOTE_MORE = False
REQUEST_PROFILE = None
PROPS = ['title','plot','year','genre','rating','mpaa','art','playcount','resume','uniqueid','season','episode','showtitle','lastplayed']


def state(name):
    return os.path.join(profile_dir(), name + '.json')


def profile_base():
    return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.myflix/')

def profile_dir():
    if REQUEST_PROFILE:return os.path.join(profile_base(),'profiles',REQUEST_PROFILE)
    return profiles.directory(profile_base())


def stale_request():
    return bool(REQUEST_PROFILE and REQUEST_PROFILE!=profiles.registry(profile_base())['active'])


def log_event(level,message,detail=''):
    try:eventlog.add(os.path.join(profile_base(),'events.sqlite'),level,'MyFlix',message,detail)
    except Exception as exc:xbmc.log('MyFlix event log unavailable: '+str(exc),xbmc.LOGWARNING)

def log_path():return os.path.join(profile_base(),'events.sqlite')

def read_kodi_events():eventlog.ingest(log_path(),xbmcvfs.translatePath('special://logpath/kodi.log'))

def profile_setup(person=None):
    name=xbmcgui.Dialog().input('Profile name',defaultt=person['name'] if person else '').strip()
    if not name:return
    old=core.load(os.path.join(profile_base(),'profiles',person['id'],'preferences.json'),{}) if person else {}
    kind=xbmcgui.Dialog().select('Profile type',['Adult','Kids'],preselect=1 if old.get('kids') else 0)
    if kind<0:return
    rating=old.get('rating','PG')
    if kind==1:
        choice=xbmcgui.Dialog().select('Kids maximum rating',['G / TV-G and younger','PG / TV-PG and younger','PG-13 / TV-14 and younger'],preselect=['G','PG','PG-13'].index(rating) if rating in ('G','PG','PG-13') else 1)
        if choice<0:return
        rating=['G','PG','PG-13'][choice]
        if not core.load(pin_path(),{}):
            set_pin()
            if not core.load(pin_path(),{}):return
    if person is None:person=profiles.create(profile_base(),name)
    else:
        data=profiles.registry(profile_base());next(p for p in data['profiles'] if p['id']==person['id'])['name']=name;profiles.save(profile_base(),data)
    core.save(os.path.join(profile_base(),'profiles',person['id'],'preferences.json'),dict(old,kids=kind==1,rating=rating))
    log_event('INFO','Profile saved: '+name,('Kids; maximum '+rating) if kind==1 else 'Adult profile')
    refresh();notify('Profile saved');xbmc.executebuiltin('ReloadSkin()')

def manage_profiles(switch=False):
    verified=False
    if prefs().get('kids'):
        if not gate():return
        verified=True
    data=profiles.registry(profile_base())
    labels=[]
    for p in data['profiles']:
        pref=core.load(os.path.join(profile_base(),'profiles',p['id'],'preferences.json'),{})
        labels.append(p['name']+(' — Kids ('+pref.get('rating','PG')+')' if pref.get('kids') else ' — Adult'))
    index=xbmcgui.Dialog().select('Switch MyFlix profile' if switch else 'Manage MyFlix profiles',labels+([] if switch else ['Create profile','Set / Change Parent PIN']))
    if index<0:return
    if not switch and index==len(labels):profile_setup();return
    if not switch and index==len(labels)+1:set_pin(verified=verified);return
    person=data['profiles'][index]
    action=0 if switch else xbmcgui.Dialog().select(person['name'],['Switch to this profile','Edit profile / Kids rating','Delete profile'])
    if action==0:
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmcgui.Dialog().ok('Stop playback first','Stop playback before switching profiles so history stays with the right person.');return
        data['active']=person['id'];profiles.save(profile_base(),data)
        for key in ('MyFlix.Detail','MyFlix.Pending','MyFlix.Series','MyFlix.ActiveRow'):WIN.clearProperty(key)
        for field in ('title','plot','year','mpaa','fanart','play','favorite','saved','favoriteLabel','watched','watchLabel','watch','playLabel','isCollection','download'):WIN.clearProperty('MyFlix.Detail.'+field)
        WIN.clearProperty('MyFlix.Toast')
        log_event('INFO','Switched profile: '+person['name'])
        WIN.setProperty('MyFlix.StateRevision',str(__import__('time').time_ns()))
        WIN.setProperty('MyFlix.LoadingProfile','true')
        WIN.clearProperty('MyFlix.Error')
        refresh();xbmc.executebuiltin('ActivateWindow(Home)')
    elif action==1:profile_setup(person)
    elif action==2:
        if person['id']==data['active'] or len(data['profiles'])==1:
            xbmcgui.Dialog().ok('Profile in use','Switch to another profile before deleting this one.');return
        if xbmcgui.Dialog().yesno('Delete '+person['name']+'?','Remove this profile and its Favorites and history?'):
            data['profiles'].remove(person);profiles.save(profile_base(),data)
            __import__('shutil').rmtree(os.path.join(profile_base(),'profiles',person['id']),ignore_errors=True)
            log_event('INFO','Deleted profile: '+person['name'])


def prefs():
    return core.load(state('preferences'), {'kids': False, 'rating': 'PG'})


def rpc(method, params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})))
    if 'error' in result:
        raise RuntimeError(result['error'].get('message', 'Kodi request failed'))
    return result.get('result', {})


def encode(item):
    return base64.urlsafe_b64encode(json.dumps(item).encode()).decode()


def decode(value):
    return json.loads(base64.urlsafe_b64decode(value).decode())


def route(mode, **kwargs):
    return BASE + '?' + urlencode(dict(mode=mode, **kwargs))


def notify(message):
    xbmcgui.Dialog().notification('MyFlix', message, xbmcgui.NOTIFICATION_INFO, 3500)


def helper_url(info, typ='movie', **kwargs):
    params=dict(info=info,tmdb_type=typ,nextpage='false',widget='true');params.update(kwargs)
    return 'plugin://plugin.video.themoviedb.helper/?'+urlencode(params)


def fetch(info, typ='movie', inherited_rating=None, **kwargs):
    global REMOTE_MORE
    paging=PARAMS.get('mode')=='browse'
    if paging:kwargs.update(nextpage='true',widget='false')
    pref=prefs()
    cache_key=hashlib.sha256(json.dumps(['navigation-v2',info,typ,kwargs,inherited_rating,bool(pref.get('kids')),pref.get('rating','PG')],sort_keys=True).encode()).hexdigest()
    cache_path=os.path.join(profile_base(),'browse-cache',cache_key+'.json')
    cached=core.load(cache_path,{})
    if cached.get('expires',0)>__import__('time').time():
        REMOTE_MORE=REMOTE_MORE or cached.get('more',False)
        return core.rows(cached['items'],pref.get('kids'),pref.get('rating','PG'))

    if not xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
        WIN.setProperty('MyFlix.Error', 'Install TMDb Helper to browse movies and shows.')
        return []
    try:
        files = rpc('Files.GetDirectory', {'directory':helper_url(info,typ,**kwargs),'media':'video','properties':PROPS}).get('files', [])
        WIN.clearProperty('MyFlix.Error')
    except Exception as exc:
        log_event('WARNING','Could not load TMDb Helper row',str(exc))
        xbmc.log('MyFlix TMDb directory failed: ' + str(exc), xbmc.LOGWARNING)
        WIN.setProperty('MyFlix.Error', 'Could not load this row. Check TMDb Helper and account settings.')
        return []
    results=[]
    for f in files:
        if f.get('label') in ('..','Previous menu') or not f.get('file'):continue
        ids=f.get('uniqueid', {})
        file_params=dict(parse_qsl(f.get('file','').split('?',1)[-1]))
        try:next_page=int(file_params.get('page','0'))>int(kwargs.get('page','1'))
        except ValueError:next_page=False
        if (next_page and not ids.get('tmdb')) or 'info=nextpage' in f.get('file',''):
            REMOTE_MORE=True;continue
        item=dict(f)
        if inherited_rating and not item.get('mpaa'):item['mpaa']=inherited_rating
        item.update(title=f.get('title') or f.get('label',''), path=f.get('file',''),
                    tmdb=ids.get('tmdb') or file_params.get('tmdb_id',''), imdb=ids.get('imdb',''), series_tmdb=ids.get('tvshow.tmdb',''), type='movie' if typ=='collection' else typ)
        if info=='seasons':
            item.update(type='season',series_tmdb=str(kwargs.get('tmdb_id','')))
            if file_params.get('season','').isdigit():item['season']=int(file_params['season'])
        if info=='episodes':
            item.update(type='episode',series_tmdb=str(kwargs.get('tmdb_id','')))
            for field in ('season','episode'):
                if file_params.get(field,'').isdigit():item[field]=int(file_params[field])
        if info=='episodes' or f.get('type')=='episode' or (typ=='movie' and f.get('showtitle') and f.get('episode',-1)>=0 and f.get('season',-1)>=0):
            item['type']='episode'
        if info in ('seasons','episodes') and item.get('season',-1)<0:continue
        if info=='episodes' and item.get('episode',-1)<0:continue
        if not item['path'] or 'info=nextpage' in item['path']:
            continue
        results.append(item)
    pref=prefs()
    if pref.get('kids'):
        from concurrent.futures import ThreadPoolExecutor
        def rate(item):
            if not core.has_rating(item):
                identifier=item.get('series_tmdb') or item.get('tmdb')
                media='tv' if item.get('type') in ('tv','episode','season') else 'movie'
                rating_key=hashlib.sha256((media+':'+str(identifier)).encode()).hexdigest()
                rating_path=os.path.join(profile_base(),'rating-cache',rating_key+'.json')
                rating=core.load(rating_path,{})
                if rating.get('expires',0)>__import__('time').time():item['mpaa']=rating.get('mpaa','');return item
                try:item['mpaa']=details.certification(profile_base(),item)
                except Exception:pass
                if not core.has_rating(item):
                    try:
                        full=rpc('Files.GetDirectory',{'directory':helper_url('details',media,tmdb_id=identifier),'media':'video','properties':PROPS}).get('files',[])
                        item['mpaa']=next((i.get('mpaa') for i in full if core.has_rating(i)),'')
                    except Exception as exc:log_event('WARNING','Could not verify title rating',str(exc))
                if core.has_rating(item):core.save(rating_path,{'mpaa':item['mpaa'],'expires':__import__('time').time()+86400})
            return item
        with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(rate,results))
        if not core.rows(results,True,pref.get('rating','PG')) and info in ('popular','trending_day'):
            results=fetch('discover',typ,with_genres='16' if typ=='movie' else '10762',with_id='true',include_adult='false',page=kwargs.get('page',1))
    results=core.rows(results,pref.get('kids'),pref.get('rating','PG'))
    if results:core.save(cache_path,{'items':results,'more':REMOTE_MORE,'expires':__import__('time').time()+900})
    return results


def mix(a,b):
    return [item for pair in zip_longest(a,b) for item in pair if item]


def collection_items(identifier):
    group=catalog.find(identifier)
    if not group:return []
    cache=core.load(os.path.join(profile_base(),'collections-cache-v2.json'),{})
    pref=prefs();scope='kids:'+pref.get('rating','PG') if pref.get('kids') else 'adult'
    cache_key=identifier+'|'+scope
    saved=cache.get(cache_key,{})
    if __import__('time').time()-saved.get('time',0)<21600:
        pref=prefs();return core.rows(saved.get('items',[]),pref.get('kids'),pref.get('rating','PG'))
    items=[];seen=set()
    for collection_id in group.get('sets',[]):
        for item in fetch('collection','collection',tmdb_id=collection_id):
            if core.key(item) not in seen:items.append(item);seen.add(core.key(item))
    for child in group.get('children',[]):
        for item in collection_items(child):
            if core.key(item) not in seen:items.append(item);seen.add(core.key(item))
    for identifier in group.get('shows',[]):
        try:
            item=details.show(profile_base(),identifier)
            if item:
                item['path']=route('seasons',item=encode(item))
                item['mpaa']=details.certification(profile_base(),item)
                if core.allowed(item,pref.get('kids'),pref.get('rating','PG')) and core.key(item) not in seen:items.append(item);seen.add(core.key(item))
        except Exception as exc:log_event('WARNING','Could not load collection show',str(exc))
    # Cache is scoped by Kids/rating to avoid storing a filtered set as an adult catalog.
    if items:
        cache[cache_key]={'time':__import__('time').time(),'items':items}
        core.save(os.path.join(profile_base(),'collections-cache-v2.json'),cache)
    return items

def collection_card(identifier):
    group=catalog.find(identifier)
    if not group:return
    items=[]
    if group.get('children'):
        for child in group['children']:
            card=collection_card(child)
            if card:items=[card];break
        if not items:
            for show_id in group.get('shows',[]):
                try:
                    item=details.show(profile_base(),show_id)
                    if not item:continue
                    item['mpaa']=details.certification(profile_base(),item)
                    pref=prefs()
                    if core.allowed(item,pref.get('kids'),pref.get('rating','PG')):items=[item];break
                except Exception:pass
    else:items=collection_items(identifier)
    if not items:return
    return dict(type='collection',tmdb=identifier,title=group['title'],plot=group['plot'],mpaa='',art=items[0].get('art',{}),path=route('collectionitems',id=identifier))


def history_items():
    records=core.load(state('history'),[])
    return [core.normalize_episode(i) for i in records]

def recent_items(typ):
    items=core.recent(history_items(),typ)
    result=[]
    for item in items:
        if item.get('type')=='tv':
            try:
                meta=details.show(profile_base(),item['tmdb'])
                if meta:item=dict(item,**meta)
            except Exception:pass
            item['path']=route('seasons',item=encode(item))
        if not core.has_rating(item):
            try:item['mpaa']=details.certification(profile_base(),item)
            except Exception:pass
        if permitted(item):result.append(item)
    return result

def permitted(item):
    if item.get('type')=='collection':return bool(collection_card(item.get('tmdb')))
    pref=prefs();return core.allowed(item,pref.get('kids'),pref.get('rating','PG'))

def detail_status(item):
    saved=any(core.key(i)==core.key(item) for i in core.load(state('favorites'),[]))
    WIN.setProperty('MyFlix.Detail.saved','true' if saved else 'false')
    WIN.setProperty('MyFlix.Detail.favoriteLabel','Remove from Favorites' if saved else 'Add to Favorites')
    watched=core.watch_status(item,history_items(),core.load(state('watched'),{}))
    WIN.setProperty('MyFlix.Detail.watched',watched)
    WIN.setProperty('MyFlix.Detail.watchLabel','Mark as unwatched' if watched=='Watched' else 'Mark as watched')
    WIN.setProperty('MyFlix.Detail.watch',route('watched',item=encode(item)))
    WIN.setProperty('MyFlix.Detail.isCollection','true' if item.get('type')=='collection' else 'false')
    WIN.setProperty('MyFlix.Detail.playLabel','View Collection' if item.get('type')=='collection' else 'View Episodes' if item.get('type')=='tv' else 'Play')

def favorite_notice(added):
    message='Added to Favorites' if added else 'Removed from Favorites'
    notify(message)
    WIN.setProperty('MyFlix.Toast',message)
    xbmc.executebuiltin('CancelAlarm(MyFlixFavoriteToast,true)')
    xbmc.executebuiltin('AlarmClock(MyFlixFavoriteToast,ClearProperty(MyFlix.Toast,home),00:05,silent)')


def emit(items, limit=24):
    if stale_request():xbmcplugin.endOfDirectory(HANDLE,cacheToDisc=False);return
    favorites={core.key(i) for i in core.load(state('favorites'), [])}
    history=history_items();watched=core.load(state('watched'),{})
    for item in items[:limit]:
        li=xbmcgui.ListItem(item.get('title') or item.get('label','Untitled'))
        if item.get('type')=='browse':
            params=item['browse'];path=route('browse',**params)
            artwork=os.path.join(os.path.dirname(__file__),'resources','explore-more.png')
            li.setArt({'poster':artwork,'thumb':artwork,'icon':artwork})
            li.setProperty('MyFlix.Kind','BROWSE')
            li.setProperty('MyFlix.Open',path)
            li.setProperty('MyFlix.Details',route('openbrowse',**params))
            xbmcplugin.addDirectoryItem(HANDLE,path,li,True)
            continue

        art=item.get('art',{})
        thumb=art.get('thumb') or art.get('landscape') or art.get('poster','')
        if item.get('type')=='episode':li.setArt(dict(art,thumb=thumb,poster=thumb,landscape=thumb))
        else:li.setArt(dict(art,poster=art.get('poster') or art.get('tvshow.poster') or thumb,thumb=thumb))
        media='tvshow' if item.get('type')=='tv' else 'set' if item.get('type')=='collection' else item.get('type','movie')
        info={k:item[k] for k in ('title','plot','year','genre','rating','mpaa','playcount','season','episode') if k in item}
        info.update(mediatype=media)
        watch_label=core.watch_status(item,history,watched)
        info['playcount']=1 if watch_label=='Watched' else 0
        li.setProperty('MyFlix.Watched',watch_label)
        li.setProperty('MyFlix.WatchLabel','Mark as unwatched' if watch_label=='Watched' else 'Mark as watched')
        li.setInfo('video',info)
        ids={k:str(item[v]) for k,v in [('tmdb','tmdb'),('imdb','imdb'),('tvshow.tmdb','series_tmdb')] if item.get(v)}
        if ids:li.setUniqueIDs(ids,'tmdb' if 'tmdb' in ids else 'imdb')
        token=encode(item)
        li.setProperty('MyFlix.Token', token)
        li.setProperty('MyFlix.Play',route('play',item=token))
        li.setProperty('MyFlix.Details',route('details',item=token))
        li.setProperty('MyFlix.Favorite',route('favorite',item=token))
        li.setProperty('MyFlix.Kind','COLLECTION' if media=='set' else 'SEASON' if media=='season' else 'SERIES' if media=='tvshow' else 'EPISODE' if media=='episode' else 'MOVIE')
        if core.key(item) in favorites:li.setProperty('MyFlix.Saved','true')
        total=item.get('total',0)
        li.setProperty('MyFlix.Progress', str(int(100*item.get('position',0)/total)) if total else '0')
        if media=='episode':li.setProperty('MyFlix.Episode', 'S{} E{}'.format(item.get('season',''),item.get('episode','')))
        li.addContextMenuItems([('Remove from MyFlix Favorites' if core.key(item) in favorites else 'Add to MyFlix Favorites',
                               'RunPlugin('+route('favorite',item=token)+')')])
        if media in ('movie','episode'):
            li.addContextMenuItems([('Download / View link','RunPlugin('+route('download',item=token)+')')])
        li.addContextMenuItems([('MyFlix Details','RunPlugin('+route('details',item=token)+')')])
        li.addContextMenuItems([('Mark as unwatched' if watch_label=='Watched' else 'Mark as watched','RunPlugin('+route('watched',item=token)+')')])
        path=item.get('path','')
        if item.get('type')=='movie' and item.get('tmdb'):
            path=helper_url('play','movie',tmdb_id=item['tmdb'])
        elif item.get('type')=='episode' and item.get('series_tmdb'):
            path=helper_url('play','tv',tmdb_id=item['series_tmdb'],season=item.get('season',0),episode=item.get('episode',0))
        elif item.get('type')=='tv' and item.get('tmdb'):
            path=route('seasons',item=token)
        elif item.get('type')=='season':path=route('episodes',item=token)
        if item.get('type')!='season':path=route('details',item=token)
        li.setProperty('MyFlix.Open',path)
        xbmcplugin.addDirectoryItem(HANDLE,path,li,True)
    content='episodes' if items and items[0].get('type')=='episode' else 'seasons' if items and items[0].get('type')=='season' else 'movies'
    xbmcplugin.setContent(HANDLE,content)
    if hasattr(xbmcplugin,'setPluginCategory'):xbmcplugin.setPluginCategory(HANDLE,PARAMS.get('label') or ('Search' if PARAMS.get('mode')=='searchresults' else 'MyFlix'))
    xbmcplugin.endOfDirectory(HANDLE,cacheToDisc=False)


def refresh():
    if stale_request():return
    revision=WIN.getProperty('MyFlix.StateRevision')
    if xbmc.getCondVisibility('Window.IsActive(Videos)') and WIN.getProperty('MyFlix.BrowseRevision')!=revision:
        WIN.setProperty('MyFlix.BrowseRevision',revision)
        xbmc.executebuiltin('Container.Refresh')
    pref=prefs()
    for addon,key,setting in [('plugin.video.themoviedb.helper','Trakt','trakt_token'),('plugin.video.umbrella','RealDebrid','realdebridtoken')]:
        installed=xbmc.getCondVisibility('System.HasAddon('+addon+')')
        status='Add-on missing'
        if installed:
            try:status='Linked' if xbmcaddon.Addon(addon).getSetting(setting) else 'Not linked'
            except Exception:status='Open account settings'
        WIN.setProperty('MyFlix.Account.'+key,status)
    data=profiles.registry(profile_base())
    WIN.setProperty('MyFlix.ProfileID',data['active'])
    WIN.setProperty('MyFlix.Profile',next(p['name'] for p in data['profiles'] if p['id']==data['active']))
    WIN.setProperty('MyFlix.Kids','true' if pref.get('kids') else 'false')
    WIN.setProperty('MyFlix.ProfileType',('Kids — '+pref.get('rating','PG')) if pref.get('kids') else 'Adult')
    history=core.rows(history_items(),pref.get('kids'),pref.get('rating','PG'))
    WIN.setProperty('MyFlix.HasHistory','true' if history else 'false')
    WIN.setProperty('MyFlix.HasContinue','true' if any(not i.get('completed') and i.get('position',0)>0 for i in history) else 'false')
    WIN.setProperty('MyFlix.HasMovieHistory','true' if any(i.get('type')=='movie' for i in history) else 'false')
    WIN.setProperty('MyFlix.HasShowHistory','true' if any(i.get('type') in ('episode','tv') for i in history) else 'false')
    favorites=core.load(state('favorites'),[])
    def cached_visible(item):
        if item.get('type')!='collection' or not pref.get('kids'):return core.allowed(item,pref.get('kids'),pref.get('rating','PG'))
        cache=core.load(os.path.join(profile_base(),'collections-cache-v2.json'),{})
        def contains(identifier):
            group=catalog.find(identifier) or {}
            saved=cache.get(identifier+'|kids:'+pref.get('rating','PG'),{})
            return any(core.allowed(i,True,pref.get('rating','PG')) for i in saved.get('items',[])) or any(contains(child) for child in group.get('children',[]))
        return contains(item.get('tmdb',''))
    visible_favorites=[i for i in favorites if cached_visible(i)]
    WIN.setProperty('MyFlix.HasFavorites','true' if visible_favorites else 'false')
    for typ,name in [('movie','Movie'),('tv','Show'),('collection','Collection')]:
        WIN.setProperty('MyFlix.Has'+name+'Favorites','true' if any(('tv' if i.get('type')=='episode' else i.get('type'))==typ for i in visible_favorites) else 'false')
    if WIN.getProperty('MyFlix.Detail'):
        try:detail_status(decode(WIN.getProperty('MyFlix.Detail')))
        except (ValueError,TypeError):pass



def pin_path():
    return os.path.join(xbmcvfs.translatePath('special://masterprofile/addon_data/myflix-parental/'), 'pin.json')


def gate():
    saved=core.load(pin_path(),{})
    if not saved:
        xbmcgui.Dialog().ok('Parent PIN required','Set a parent PIN in MyFlix Settings before enabling Kids mode.')
        return False
    entered=xbmcgui.Dialog().input('Parent PIN',type=xbmcgui.INPUT_NUMERIC,option=xbmcgui.ALPHANUM_HIDE_INPUT)
    digest=hashlib.pbkdf2_hmac('sha256',entered.encode(),bytes.fromhex(saved['salt']),120000).hex()
    if not __import__('hmac').compare_digest(digest,saved['hash']):
        notify('Incorrect PIN');return False
    return True


def set_pin(verified=False):
    if core.load(pin_path(),{}) and not verified and not gate():return
    first=xbmcgui.Dialog().input('New parent PIN (at least 4 digits)',type=xbmcgui.INPUT_NUMERIC,option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not first.isdigit() or len(first)<4:return
    second=xbmcgui.Dialog().input('Confirm parent PIN',type=xbmcgui.INPUT_NUMERIC,option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if first!=second:notify('PINs did not match');return
    salt=secrets.token_bytes(16)
    core.save(pin_path(),{'salt':salt.hex(),'hash':hashlib.pbkdf2_hmac('sha256',first.encode(),salt,120000).hex()})
    notify('Parent PIN saved');log_event('INFO','Parent PIN changed')


def navigation(title,params):
    return {'type':'browse','title':title,'browse':params}


def feed_items():
    kind=PARAMS.get('kind','popular');typ=PARAMS.get('type','movie')
    try:page=max(1,int(PARAMS.get('page','1')))
    except ValueError:page=1
    if kind=='collections':
        progress=xbmcgui.DialogProgressBG() if hasattr(xbmcgui,'DialogProgressBG') else None
        if progress:progress.create('MyFlix Collections','Loading collections and checking profile ratings')
        items=[]
        try:
            for index,group in enumerate(catalog.COLLECTIONS):
                if progress:progress.update(int(100*index/len(catalog.COLLECTIONS)),message='Checking '+group['title'])
                card=collection_card(group['id'])
                if card:items.append(card)
            return items
        finally:
            if progress:progress.close()
    if kind=='collectioncontents':
        identifier=PARAMS.get('id','');group=catalog.find(identifier) or {}
        if group.get('children'):
            items=[card for child in group['children'] if (card:=collection_card(child))]
            items.extend(i for i in collection_items(identifier) if i.get('type')=='tv')
            return items
        return collection_items(identifier)
    if kind=='history':return recent_items(typ)
    if kind in ('continue','favorites'):
        source=core.load(state('favorites' if kind=='favorites' else 'history'),[])
        if kind=='continue':source=[core.normalize_episode(i) for i in source]
        if typ!='both':source=[i for i in source if ('tv' if i.get('type')=='episode' else i.get('type'))==typ]
        items=[i for i in source if permitted(i)]
        items=[(collection_card(i['tmdb']) or i) if i.get('type')=='collection' else i for i in items]
        if kind=='continue':items=[i for i in items if not i.get('completed') and i.get('position',0)>0]
        return items
    if kind=='recommended':
        history=history_items()
        recent=next((i for i in history if i.get('tmdb') or i.get('series_tmdb')),None)
        items=fetch('recommendations','tv' if recent.get('series_tmdb') else 'movie',tmdb_id=recent.get('series_tmdb') or recent['tmdb'],page=page) if recent else []
        return items or mix(fetch('popular','movie',page=page),fetch('popular','tv',page=page))
    if kind=='genre':return fetch('discover',typ,with_genres=PARAMS.get('genre',''),with_id='true',include_adult='false',page=page)
    if kind=='next':
        items=[];seen=set()
        for previous in history_items():
            series=previous.get('series_tmdb')
            if previous.get('type')!='episode' or not previous.get('completed') or not series or series in seen:continue
            seen.add(series)
            following=fetch('episodes','tv',tmdb_id=series,season=previous.get('season',0),inherited_rating=previous.get('mpaa'))
            candidate=next((i for i in following if i.get('episode')==previous.get('episode',0)+1),None)
            if candidate and core.watch_status(candidate,history_items(),core.load(state('watched'),{}))!='Watched':items.append(candidate)
        return items
    return fetch(kind,typ,page=page)


def download_folder():
    return xbmcaddon.Addon('plugin.video.myflix').getSetting('download_folder')


def configure_downloads():
    if prefs().get('kids') and not gate():
        return
    xbmcaddon.Addon('plugin.video.myflix').openSettings()


def download_video(item, url, current):
    dialog = xbmcgui.Dialog()
    title = item.get('title') or 'Video'
    address = url.partition('|')[0]
    choice = dialog.select(title, [
        xbmcgui.ListItem(label='Download video', label2=address),
        xbmcgui.ListItem(label='View download link', label2=address)], useDetails=True)
    if choice < 0:
        return
    if choice == 1:
        dialog.textviewer('Download link', address)
        if not dialog.yesno('Download video?', title):
            return
    if not current():
        return
    folder = download_folder()
    if not folder:
        configure_downloads()
        folder = download_folder()
    if not folder or not current():
        return
    profile = profile_dir()
    monitor = xbmc.Monitor()
    progress = xbmcgui.DialogProgress()
    progress.create('MyFlix Download', title)

    def update(received, total):
        progress.update(min(100, int(100 * received / total)) if total else 0,
                        '{}\n{:.1f} MB downloaded'.format(title, received / 1048576))
        return current() and not progress.iscanceled() and not monitor.abortRequested()

    try:
        completed = downloads.save(profile, folder, item, url, update, profile_base())
    except ValueError as exc:
        message = str(exc)
        if not message.startswith(('Choose a direct', 'The source', 'The download', 'Could not choose')):
            message = 'The source returned invalid download information.'
        dialog.ok('Download failed', message)
    except downloads.FolderError:
        dialog.ok('Download folder unavailable', 'MyFlix could not write to your selected folder. Check that the drive or share is connected and writable.')
    except (OSError, RuntimeError, sqlite3.Error):
        dialog.ok('Download failed', 'Check the source, free space, and write access to the download folder.')
    else:
        notify('Added to MyFlix Downloads' if completed else 'Download cancelled')
    finally:
        progress.close()


def download_directory(mode):
    def add(label, target, folder=True):
        xbmcplugin.addDirectoryItem(HANDLE, target, xbmcgui.ListItem(label=label), folder)

    if mode == 'root':
        add('Browse MyFlix', route('browse',kind='popular',type='movie',label='Popular Movies'))
        add('Downloads', route('downloads'))
        add('MyFlix Settings', route('settings'), False)
    elif mode == 'downloads':
        add('Movies', route('downloadmovies'))
        add('TV Shows', route('downloadshows'))
        add('Download settings', route('downloadsettings'), False)
    else:
        rows = [row for row in downloads.entries(profile_dir()) if permitted(row[2])]
        if mode == 'downloadshows':
            shows = {downloads.show_key(item):downloads.show_name(item) for _, _, item in rows
                     if item.get('type') == 'episode'}
            for key, label in sorted(shows.items(), key=lambda pair: pair[1].casefold()):
                add(label, route('downloadepisodes',show=key))
        else:
            episodes = mode == 'downloadepisodes'
            if episodes:
                rows = [row for row in rows if row[2].get('type') == 'episode'
                        and downloads.show_key(row[2]) == PARAMS.get('show')]
                rows.sort(key=lambda row: downloads.episode_label(row[2]))
            else:
                rows = [row for row in rows if row[2].get('type') == 'movie']
                rows.sort(key=lambda row: (row[2].get('title') or '').casefold())
            for _, path, item in rows:
                title = item.get('title') or 'Untitled'
                label = downloads.episode_label(item) + ' - ' + title if episodes else title
                li = xbmcgui.ListItem(label=label, path=path)
                li.setArt(item.get('art') or {})
                li.setProperty('IsPlayable','true')
                xbmcplugin.addDirectoryItem(HANDLE,path,li,False)
            xbmcplugin.setContent(HANDLE,'episodes' if episodes else 'movies')
    xbmcplugin.endOfDirectory(HANDLE,cacheToDisc=False)


def main():
    global REQUEST_PROFILE
    mode=PARAMS.get('mode','root')
    if mode in ('feed','browse','searchresults','collectionitems','seasons','episodes'):
        data=profiles.registry(profile_base())
        requested=PARAMS.get('profile') or data['active']
        if REQUEST_PROFILE is None:REQUEST_PROFILE=requested if any(p['id']==requested for p in data['profiles']) else data['active']
        if stale_request():emit([]);return
    if mode in ('root','downloads','downloadmovies','downloadshows','downloadepisodes') and HANDLE>=0:
        download_directory(mode);return
    if mode=='opendownloads':
        xbmc.executebuiltin('ActivateWindow(Videos,"'+route('downloads')+'",return)');return
    if mode=='downloadsettings':
        configure_downloads();return
    if mode=='combinedresolve':
        job=sourcejobs.read(profile_base(),PARAMS.get('job',''))
        if not job or job.get('profile')!=profile_dir() or not permitted(job.get('item',{})):
            if HANDLE>=0:xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem())
            return
        expected=profile_dir()
        url=sourcelist.resolve(profile_base(),PARAMS['job'],lambda:profile_dir()==expected,log_event)
        if not url:WIN.clearProperty('MyFlix.Pending')
        if HANDLE>=0:
            li=xbmcgui.ListItem(label=job['item'].get('title',''),path=url or '')
            li.setArt(job['item'].get('art',{}))
            li.setInfo('video',{'title':job['item'].get('title',''),'mediatype':job['item'].get('type','movie')})
            xbmcplugin.setResolvedUrl(HANDLE,bool(url),li)
        return
    refresh()
    if mode=='clearlogs':
        if prefs().get('kids') and not gate():return
        if xbmcgui.Dialog().yesno('Clear all MyFlix logs?','Delete every MyFlix event entry? New events will still be recorded.'):
            eventlog.clear(log_path(),xbmcvfs.translatePath('special://logpath/kodi.log'))
            notify('MyFlix logs cleared');xbmc.executebuiltin('ReloadSkin()')
        return
    if mode in ('logs','logfeed','logdetail'):
        if prefs().get('kids') and mode=='logs' and not gate():return
        read_kodi_events()
        if mode=='logs':xbmc.executebuiltin('ActivateWindow(22006)');return
        if mode=='logdetail':
            entry=eventlog.get(log_path(),int(PARAMS.get('id',0)))
            if entry:xbmcgui.Dialog().textviewer(entry['level']+' — '+entry['source'],entry['time']+'\n'+entry['message']+'\n\n'+entry['detail'])
            return
        for entry in eventlog.rows(log_path()):
            item=xbmcgui.ListItem(entry['message'])
            for key in ('time','level','source','detail'):item.setProperty('MyFlix.Log.'+key,entry[key])
            item.setProperty('MyFlix.Log.color',eventlog.COLORS[entry['level']])
            item.setProperty('MyFlix.Log.action',route('logdetail',id=entry['id']))
            xbmcplugin.addDirectoryItem(HANDLE,route('logdetail',id=entry['id']),item,False)
        xbmcplugin.endOfDirectory(HANDLE,cacheToDisc=False);return
    if mode=='editprofile':
        if prefs().get('kids') and not gate():return
        data=profiles.registry(profile_base());profile_setup(next(p for p in data['profiles'] if p['id']==data['active']));return
    if mode=='favoritecurrent':
        item={k:xbmc.getInfoLabel(v) for k,v in {'title':'ListItem.Title','plot':'ListItem.Plot','mpaa':'ListItem.Mpaa','tmdb':'ListItem.UniqueID(tmdb)','imdb':'ListItem.UniqueID(imdb)','path':'ListItem.FileNameAndPath'}.items()}
        item['title']=item['title'] or xbmc.getInfoLabel('ListItem.Label')
        item['type']='episode' if xbmc.getInfoLabel('ListItem.DBType')=='episode' else 'tv' if xbmc.getInfoLabel('ListItem.DBType')=='tvshow' else 'movie'
        item['series_tmdb']=xbmc.getInfoLabel('ListItem.UniqueID(tvshow.tmdb)')
        item['art']={k:xbmc.getInfoLabel('ListItem.Art('+k+')') for k in ('poster','thumb','fanart','landscape')}
        for k in ('year','season','episode'):
            value=xbmc.getInfoLabel('ListItem.'+k.title())
            if value.isdigit():item[k]=int(value)
        PARAMS['item']=encode(item);mode='favorite'
    if mode=='detailsback':
        try:item=decode(WIN.getProperty('MyFlix.Detail'))
        except Exception:item={}
        if item.get('type')=='episode' and (item.get('series_tmdb') or item.get('tvshow.tmdb')):
            parent=item.get('season_parent') or dict(type='season',series_tmdb=item.get('series_tmdb') or item.get('tvshow.tmdb'),season=item.get('season',0),showtitle=item.get('showtitle') or item.get('tvshowtitle',''),mpaa=item.get('mpaa',''))
            xbmc.executebuiltin('ActivateWindow(Videos,"'+route('episodes',item=encode(parent))+'",return)')
        else:xbmc.executebuiltin('Action(Back)')
        return
    if mode in ('favorite','details','play','watched','download'):

        item=decode(PARAMS.get('item',''))
        pref=prefs()
        if not permitted(item):
            notify('This title is outside this Kids profile’s rating limit.');return
        if mode=='favorite':
            added=core.favorite_toggle(state('favorites'),item)
            WIN.setProperty('MyFlix.StateRevision',str(__import__('time').time_ns()))
            detail_status(item);favorite_notice(added)
            log_event('INFO',('Added Favorite: ' if added else 'Removed Favorite: ')+item.get('title',''))
            refresh()
            if not xbmc.getCondVisibility('Window.IsActive(22005)'):xbmc.executebuiltin('ReloadSkin()')
            return
        if mode=='watched':
            records=core.load(state('watched'),{})
            value=core.watch_status(item,history_items(),records)!='Watched'
            if item.get('type')=='season':
                episodes=fetch('episodes','tv',tmdb_id=item.get('series_tmdb') or item.get('tmdb'),season=item.get('season',0),inherited_rating=item.get('mpaa'))
                if not episodes:notify('Could not load the season’s episodes. Please try again.');return
                for episode in episodes:core.set_episode_watched(records,episode,value)
                records.pop(core.key(item),None)
                item['episode_count']=len(episodes)
            elif item.get('type')=='episode':core.set_episode_watched(records,item,value)
            else:records[core.key(item)]=value
            core.save(state('watched'),records);detail_status(item)
            WIN.setProperty('MyFlix.StateRevision',str(__import__('time').time_ns()))
            notify('Marked as watched' if value else 'Marked as unwatched')
            refresh()
            return
        if mode=='details':
            WIN.setProperty('MyFlix.Detail',encode(item));detail_status(item)
            for field in ('title','plot','year','mpaa'):
                WIN.setProperty('MyFlix.Detail.'+field,str(item.get(field,'')))
            WIN.setProperty('MyFlix.Detail.fanart',item.get('art',{}).get('fanart',''))
            WIN.setProperty('MyFlix.Detail.play',route('play',item=encode(item)))
            if item.get('type') in ('movie','episode'):
                WIN.setProperty('MyFlix.Detail.download',route('download',item=encode(item)))
            else:
                WIN.clearProperty('MyFlix.Detail.download')
            WIN.setProperty('MyFlix.Detail.favorite',route('favorite',item=encode(item)))
            xbmc.executebuiltin('ActivateWindow(22005)')
            if HANDLE>=0:xbmcplugin.endOfDirectory(HANDLE,succeeded=True,cacheToDisc=False)
            return
        if mode=='download' and item.get('type') not in ('movie','episode'):
            return
        if item.get('type')=='collection':
            xbmc.executebuiltin('ActivateWindow(Videos,"'+route('collectionitems',id=item['tmdb'])+'",return)');return
        if item.get('type')=='tv' or ('info=seasons' in item.get('path','')):
            WIN.setProperty('MyFlix.Series',encode(dict(item,profile=profile_dir(),requested=__import__('time').time())))
            xbmc.executebuiltin('ActivateWindow(Videos,"'+route('seasons',item=encode(item))+'",return)');return
        # Fetch identifiers required by native providers before launching their workers.
        expected=profile_dir()
        native=sourcejobs.prepare_item(item)
        try:
            typ='tv' if item.get('type')=='episode' else 'movie'
            identifier=item.get('series_tmdb') or item.get('tmdb')
            if identifier:
                meta=details.request(profile_base(),typ,identifier)
                ids=details.request(profile_base(),typ,identifier,'external_ids')
                native['imdb']=item.get('imdb') or ids.get('imdb_id') or meta.get('imdb_id','')
                native['tvdb']=item.get('tvdb') or ids.get('tvdb_id','')
                native['year']=str(meta.get('first_air_date' if typ=='tv' else 'release_date',''))[:4] or item.get('year','')
                if typ=='tv':native['tvshowtitle']=meta.get('name') or item.get('showtitle') or item.get('title','')
                native['source_meta']=dict(native,mediatype=item.get('type','movie'))
        except Exception as exc:log_event('WARNING','Source metadata lookup failed',str(exc))
        native['source_meta']=dict(native,mediatype=item.get('type','movie'))
        current = lambda: profile_dir() == expected
        selection=sourcelist.choose(profile_base(),expected,native,current,log_event,download=mode=='download')
        if mode=='download':
            if selection:
                url=sourcelist.resolve(profile_base(),selection,current,log_event,download=True)
                if url and current():
                    download_video(item,url,current)
            return
        if selection is None:return
        if selection:
            WIN.setProperty('MyFlix.Pending',encode(dict(item,profile=expected,requested=__import__('time').time())))
            xbmc.executebuiltin('PlayMedia("'+route('combinedresolve',job=selection)+'")')
            return
        log_event('INFO','Playback requested: '+item.get('title',''), 'Profile: '+WIN.getProperty('MyFlix.Profile')+'; player: TMDb Helper / Umbrella')
        # Pending metadata is scoped to this profile and consumed only on actual playback.
        pending=dict(item, profile=profile_dir(), requested=__import__('time').time())
        WIN.setProperty('MyFlix.Pending',encode(pending))
        if item.get('tmdb'):
            args={'info':'play','tmdb_type':'tv' if item.get('type')=='episode' else 'movie','tmdb_id':item.get('series_tmdb') or item['tmdb']}
            if item.get('type')=='episode':args.update(season=item.get('season',0),episode=item.get('episode',0))
            path='plugin://plugin.video.themoviedb.helper/?'+urlencode(args)
        else:path=item['path']
        if item.get('tmdb'):
            helper_data=xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper/')
            for folder in ('players','reconfigured_players'):os.makedirs(os.path.join(helper_data,folder),exist_ok=True)
        # PlayMedia creates the Kodi plugin playback handle required by setResolvedUrl.
        log_event('INFO','Starting Kodi playback handoff',path)
        xbmc.executebuiltin('PlayMedia("'+path+'")')
        return
    if mode=='options':
        cid=WIN.getProperty('MyFlix.ActiveRow')
        token=xbmc.getInfoLabel('Container('+cid+').ListItem.Property(MyFlix.Token)') if cid.isdigit() else ''
        if not token:token=WIN.getProperty('MyFlix.Detail')
        actions = []
        if token:
            actions.extend([('Details','details'),('Play / Episodes','play')])
            if decode(token).get('type') in ('movie','episode'):
                actions.append(('Download / View link','download'))
        actions.extend([('Downloads','opendownloads'),('Download settings','downloadsettings'),('Settings','settings')])
        choice=xbmcgui.Dialog().select('MyFlix options',[label for label, _ in actions])
        if choice<0:return
        action=actions[choice][1]
        target=route(action,item=token) if action in ('details','play','download') else route(action)
        xbmc.executebuiltin('RunPlugin('+target+')')
        return
    if mode in ('accountmanager','accounttrakt','accountdebrid'):
        if prefs().get('kids') and not gate():return
        if not xbmc.getCondVisibility('System.HasAddon(script.module.acctmgr)'):
            xbmcgui.Dialog().ok('Account Manager needed','Run MyFlix Installer → Install / repair MyFlix, then restart Kodi.');return
        log_event('INFO','Opened shared Account Manager')
        xbmc.executebuiltin('RunAddon(script.module.acctmgr)')
        return
    if mode in ('accounttrakt','accountdebrid','accountumbrella'):
        if prefs().get('kids') and not gate():return
        if mode=='accountumbrella':
            xbmc.executebuiltin('Addon.OpenSettings(plugin.video.umbrella)');return
        services=[('TMDb Helper','plugin.video.themoviedb.helper','trakt_token',
                   'RunScript(plugin.video.themoviedb.helper,authenticate_trakt)'),
                  ('Umbrella','plugin.video.umbrella','trakt.token','Addon.OpenSettings(plugin.video.umbrella)'),
                  ('POV','plugin.video.pov','trakt.token','RunPlugin(plugin://plugin.video.pov/?mode=myservices)')] if mode=='accounttrakt' else [
                  ('Umbrella','plugin.video.umbrella','realdebridtoken','RunPlugin(plugin://plugin.video.umbrella/?action=rd_Authorize)'),
                  ('POV','plugin.video.pov','rd.token','RunPlugin(plugin://plugin.video.pov/?mode=myservices)')]
        labels=[]
        for name,addon,key,command in services:
            installed=xbmc.getCondVisibility('System.HasAddon('+addon+')')
            linked=bool(xbmcaddon.Addon(addon).getSetting(key)) if installed else False
            labels.append(name+' · '+('Linked' if linked else 'Not linked' if installed else 'Not installed'))
        choice=xbmcgui.Dialog().select('Trakt accounts' if mode=='accounttrakt' else 'Real-Debrid accounts',labels)
        if choice<0:return
        name,addon,key,command=services[choice]
        if not xbmc.getCondVisibility('System.HasAddon('+addon+')'):
            xbmcgui.Dialog().ok('Add-on needed','Run MyFlix Installer → Install / repair MyFlix.');return
        log_event('INFO','Account authorization requested',name)
        xbmc.executebuiltin(command)
        return
    if mode=='refresh':return
    if mode=='search':
        query=xbmcgui.Dialog().input('Search movies and shows')
        if query:xbmc.executebuiltin('ActivateWindow(Videos,"'+route('searchresults',query=query)+'",return)')
        return
    if mode in ('seasons','episodes'):
        parent=decode(PARAMS.get('item',''))
        if not permitted(parent):emit([]);return
        if mode=='seasons':WIN.setProperty('MyFlix.Series',encode(dict(parent,profile=profile_dir(),requested=__import__('time').time())))
        show=parent.get('series_tmdb') or parent.get('tmdb')
        link=dict(parse_qsl(parent.get('path','').split('?',1)[-1]))
        show=show or link.get('tmdb_id')
        if not str(show or '').isdigit():
            log_event('ERROR','Missing show ID for episode navigation')
            notify('Show information is incomplete. Reopen the show from Search.');emit([]);return
        if mode=='episodes' and link.get('season','').isdigit():parent['season']=int(link['season'])
        args={'tmdb_id':show}
        if mode=='episodes':args['season']=parent.get('season',0)
        items=fetch(mode,'tv',inherited_rating=parent.get('mpaa'),**args)
        seen=set();unique=[]
        for entry in items:
            number=entry.get('season') if mode=='seasons' else entry.get('episode')
            identity=(show,number)
            if identity not in seen:seen.add(identity);unique.append(entry)
        items=unique
        data={}
        try:data=details.request(profile_base(),'tv',show,*(['season',parent.get('season',0)] if mode=='episodes' else []))
        except Exception as exc:log_event('WARNING','Could not load season metadata',str(exc))
        for item in items:
            item['series_tmdb']=show
            item['showtitle']=parent.get('tvshowtitle') or parent.get('showtitle') or parent.get('title','')
            item['tvshowtitle']=item['showtitle']
            item['show_year']=parent.get('show_year') or parent.get('year','')
            if mode=='seasons':
                item['type']='season'
                meta=next((i for i in data.get('seasons',[]) if i.get('season_number')==item.get('season')),{})
                item['episode_count']=meta.get('episode_count') or item.get('episode_count',0)
                poster=details.image(meta.get('poster_path')) or item.get('art',{}).get('season.poster')
                if poster:item['art']=dict(item.get('art',{}),poster=poster,thumb=poster)
                if not item['episode_count']:
                    item['episode_count']=len(fetch('episodes','tv',tmdb_id=show,season=item.get('season',0),inherited_rating=parent.get('mpaa')))
            else:
                meta=next((i for i in data.get('episodes',[]) if i.get('episode_number')==item.get('episode')),{})
                item['season_parent']=dict(parent,type='season',series_tmdb=show,season=parent.get('season',0))
                still=details.image(meta.get('still_path'))
                if still:item['art']=dict(item.get('art',{}),thumb=still,poster=still,landscape=still)
        PARAMS['label']=(parent.get('showtitle') or parent.get('title',''))
        emit(items,limit=500);return
    if mode=='collectionitems':
        PARAMS.update(mode='browse',kind='collectioncontents',type='collection')
        PARAMS['label']=(catalog.find(PARAMS.get('id','')) or {}).get('title','Collection')
        return main()
    if mode=='searchresults':
        emit(mix(fetch('search','movie',query=PARAMS.get('query','')),fetch('search','tv',query=PARAMS.get('query',''))));return
    if mode=='setpin':
        set_pin();return
    if mode in ('switch','settings','profiles'):
        if mode=='settings':
            if prefs().get('kids') and not gate():return
            if xbmc.getSkinDir()=='skin.myflix':
                xbmc.executebuiltin('ActivateWindow(22004)')
            else:
                xbmcaddon.Addon('plugin.video.myflix').openSettings()
        else:manage_profiles(switch=mode=='switch')
        return
    if mode in ('kidstoggle','rating','clearhistory') and prefs().get('kids') and not gate():return
    if mode=='kidstoggle':
        pref=prefs()
        if not pref.get('kids') and not core.load(pin_path(),{}):
            set_pin()
            if not core.load(pin_path(),{}):return
        pref['kids']=not pref.get('kids',False);core.save(state('preferences'),pref)
        refresh();xbmc.executebuiltin('ReloadSkin()');return
    if mode=='rating':
        choice=xbmcgui.Dialog().select('Kids maximum rating',['G / TV-G and younger','PG / TV-PG and younger'])
        if choice>=0:
            pref=prefs();pref['rating']='G' if choice==0 else 'PG';core.save(state('preferences'),pref)
            refresh();xbmc.executebuiltin('ReloadSkin()')
        return
    if mode=='importhistory':
        if prefs().get('kids') and not gate():return
        if not xbmcgui.Dialog().yesno('Import Trakt history into this profile?', 'The linked Trakt account is shared by all MyFlix profiles. Import its history only into the intended profile; it cannot be separated automatically.'):
            return
        incoming=fetch('trakt_history','movie')+fetch('trakt_history','tv')
        existing=core.load(state('history'),[])
        identities={core.key(i) for i in existing}
        for item in incoming:
            if core.key(item) not in identities:
                item.update(completed=True,lastwatched=__import__('time').time(),position=0,total=0)
                existing.append(item);identities.add(core.key(item))
        core.save(state('history'),existing[:100]);refresh()
        notify('Imported watched titles for this profile');xbmc.executebuiltin('ReloadSkin()');return
    if mode=='clearhistory':
        if xbmcgui.Dialog().yesno('Clear this profile’s history?','Other profiles are not affected.'):
            core.save(state('history'),[]);refresh();xbmc.executebuiltin('ReloadSkin()')
        return
    if mode=='openbrowse':
        params={k:PARAMS[k] for k in ('kind','type','genre','label','page','id') if k in PARAMS}
        xbmc.executebuiltin('ActivateWindow(Videos,"'+route('browse',**params)+'",return)');return
    if mode in ('feed','browse'):
        items=feed_items()
        if stale_request():emit([]);return
        if PARAMS.get('kind')=='recommended':
            WIN.clearProperty('MyFlix.LoadingProfile')
            if not items:
                message='No verified titles loaded for this profile. Check the Kids rating limit or view the MyFlix log.' if prefs().get('kids') else 'Browse results could not load. Check TMDb Helper or view the MyFlix log.'
                WIN.setProperty('MyFlix.Error',message)
                log_event('WARNING',message)
        kind=PARAMS.get('kind','popular');typ=PARAMS.get('type','movie')
        params={k:PARAMS[k] for k in ('kind','type','genre','label','id') if k in PARAMS}
        params.setdefault('kind',kind);params.setdefault('type',typ)
        if mode=='browse':
            try:page=max(1,int(PARAMS.get('page','1')))
            except ValueError:page=1
            local=kind in ('history','continue','favorites','collections','collectioncontents','next')
            more=REMOTE_MORE
            if local:
                start=(page-1)*40;more=len(items)>start+40;items=items[start:start+40]
            if page>1:items.insert(0,navigation('Previous Page',dict(params,page=page-1)))
            if more:items.append(navigation('Next Page',dict(params,page=page+1)))
            PARAMS['label']=(params.get('label') or kind.replace('_',' ').title())+' — Page '+str(page)
            emit(items,limit=500);return
        # Widget rows show 23 titles plus one actionable Explore More card.
        if items and PARAMS.get('explore')=='true':
            items=(items if kind=='collections' else items[:23])+[navigation('Explore More',dict(params,page=1))]
        emit(items,limit=500 if kind=='collections' else 24);return
    notify('Open MyFlix through the MyFlix skin.')
    if HANDLE>=0:emit([])

try:
    main()
except Exception as exc:
    log_event('ERROR','Action failed: '+PARAMS.get('mode','root'),__import__('traceback').format_exc())
    xbmc.log('MyFlix: '+str(exc),xbmc.LOGERROR)
    notify('Could not complete this action. Check the Kodi log.')
    if HANDLE>=0:xbmcplugin.endOfDirectory(HANDLE,succeeded=False)

finally:
    WIN = None
