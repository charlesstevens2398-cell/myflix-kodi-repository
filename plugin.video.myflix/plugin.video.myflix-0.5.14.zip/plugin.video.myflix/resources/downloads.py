"""Download resolved video files and index completed transfers per profile."""
from contextlib import closing
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
from urllib.parse import unquote, urlsplit
from urllib.request import Request, urlopen

VIDEO_EXTENSIONS = {'.avi', '.m2ts', '.m4v', '.mkv', '.mov', '.mp4', '.mpeg',
                    '.mpg', '.ts', '.webm', '.wmv'}


def open_index(profile):
    os.makedirs(profile, exist_ok=True)
    db = sqlite3.connect(os.path.join(profile, 'downloads.sqlite'))
    db.execute('CREATE TABLE IF NOT EXISTS downloads (id TEXT PRIMARY KEY, path TEXT, item TEXT)')
    return db


def entries(profile):
    with closing(open_index(profile)) as db:
        rows = db.execute('SELECT id, path, item FROM downloads ORDER BY rowid DESC').fetchall()
    return [(token, path, json.loads(item)) for token, path, item in rows if os.path.isfile(path)]


def safe_name(value):
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(value or 'Untitled'))
    value = value[:100].strip(' .') or 'Untitled'
    if re.fullmatch(r'CON|PRN|AUX|NUL|COM[0-9¹²³]|LPT[0-9¹²³]', value.split('.')[0], re.I):
        return '_' + value
    return value


def show_name(item):
    return item.get('showtitle') or item.get('tvshowtitle') or 'Unknown show'


def show_key(item):
    return str(item.get('series_tmdb') or show_name(item))


def episode_label(item):
    return 'S{:02d}E{:02d}'.format(int(item.get('season') or 0), int(item.get('episode') or 0))


def save(profile, folder, item, url, progress):
    address, _, options = url.partition('|')
    from urllib.parse import parse_qsl
    request = Request(address, headers=dict(parse_qsl(options)))
    with urlopen(request, timeout=20) as response:
        mime = response.headers.get_content_type()
        name = response.headers.get_filename() or unquote(urlsplit(response.geturl()).path)
        extension = Path(name).suffix.lower()
        if (mime.startswith('text/') or mime in ('application/json', 'application/dash+xml',
                'application/vnd.apple.mpegurl', 'application/x-mpegurl') or
                (extension not in VIDEO_EXTENSIONS and not mime.startswith('video/'))):
            raise ValueError('Choose a direct video file. This source returned a page or stream playlist.')
        if extension not in VIDEO_EXTENSIONS:
            extension = {'video/x-matroska': '.mkv', 'video/webm': '.webm',
                         'video/quicktime': '.mov', 'video/mp2t': '.ts'}.get(mime, '.mp4')
        title = item.get('title') or 'Untitled'
        if item.get('type') == 'episode':
            destination = Path(folder, 'TV Shows', safe_name(show_name(item)),
                               'Season {:02d}'.format(int(item.get('season') or 0)))
            name = episode_label(item) + ' - ' + safe_name(title)
        else:
            destination = Path(folder, 'Movies')
            year = str(item.get('year') or '')
            name = safe_name(title) + (' (' + year + ')' if re.fullmatch(r'\d{4}', year) else '')
        destination.mkdir(parents=True, exist_ok=True)
        token = secrets.token_hex(16)
        partial = destination / ('.myflix-' + token + '.part')
        path = destination / (name + extension)
        total = int(response.headers.get('Content-Length') or 0)
        if response.headers.get('Content-Range'):
            raise ValueError('The source returned an incomplete video file.')
        received = 0
        published = None
        try:
            with partial.open('xb') as output:
                while progress(received, total):
                    chunk = response.read(256 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
                    received += len(chunk)
                else:
                    return False
            if not received or (total and received != total):
                raise ValueError('The download ended before the complete video was received.')
            # Serialize final filenames across profiles sharing the same folder.
            for number in range(1, 10000):
                path = destination / (name + (' (' + str(number) + ')' if number > 1 else '') + extension)
                marker = path.with_name(path.name + '.myflix-lock')
                try:
                    claim = marker.open('xb')
                except FileExistsError:
                    continue
                try:
                    claim.close()
                    if path.exists() or path.is_symlink():
                        continue
                    os.replace(partial, path)
                    published = path
                    break
                finally:
                    marker.unlink(missing_ok=True)
            if published is None:
                raise ValueError('Could not choose an available filename.')
            with closing(open_index(profile)) as db, db:
                db.execute('INSERT INTO downloads VALUES (?,?,?)',
                           (token, str(published), json.dumps(item, ensure_ascii=False)))
        except Exception:
            if published is not None:
                published.unlink(missing_ok=True)
            raise
        finally:
            partial.unlink(missing_ok=True)
    return True
