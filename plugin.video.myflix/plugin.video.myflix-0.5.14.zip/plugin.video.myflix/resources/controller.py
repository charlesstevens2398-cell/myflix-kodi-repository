"""Install scoped controller mappings only while MyFlix is the active skin."""
import os
import xml.etree.ElementTree as E
import xbmc,xbmcvfs

def sync():
    path=xbmcvfs.translatePath('special://profile/keymaps/myflix-controller.xml')
    enabled=xbmc.getSkinDir()=='skin.myflix'
    if not enabled:
        if os.path.exists(path):os.remove(path);xbmc.executebuiltin('Action(reloadkeymaps)')
        return
    root=E.Element('keymap')
    for name in ['home','window22001','window22002','window22003','window22004','window22005','window22006','window22007']:
        w=E.SubElement(root,name);j=E.SubElement(w,'joystick',profile='game.controller.default')
        E.SubElement(j,'a').text='Select'
        E.SubElement(j,'a',holdtime='500').text='RunPlugin(plugin://plugin.video.myflix/?mode=settings)'
        E.SubElement(j,'x').text='RunPlugin(plugin://plugin.video.myflix/?mode=options)'
        if name=='window22005':
            action='RunPlugin(plugin://plugin.video.myflix/?mode=detailsback)'
            E.SubElement(j,'b').text=action
            keyboard=E.SubElement(w,'keyboard')
            for key in ('backspace','escape'):E.SubElement(keyboard,key).text=action
            remote=E.SubElement(w,'remote');E.SubElement(remote,'back').text=action
    text=E.tostring(root,encoding='unicode')
    if os.path.isfile(path) and open(path).read()==text:return
    os.makedirs(os.path.dirname(path),exist_ok=True)
    with open(path,'w') as f:f.write(text)
    xbmc.executebuiltin('Action(reloadkeymaps)')
