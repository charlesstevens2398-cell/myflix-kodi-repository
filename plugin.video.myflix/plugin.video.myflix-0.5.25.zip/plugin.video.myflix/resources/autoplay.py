"""Episode order and the number of episodes allowed before a watching check."""
import hashlib

INITIAL_EPISODES = 3
CONTINUE_EPISODES = 3
PLAYBACK_JOB = 'MyFlix.AutoplayJob'


def file_key(path):
    return hashlib.sha256(path.partition('|')[0].encode('utf-8')).hexdigest()


def valid_episode(item):
    try:
        return (item.get('type') == 'episode' and
                str(item.get('series_tmdb') or '').isdigit() and
                int(item.get('season')) >= 0 and int(item.get('episode')) >= 1)
    except (TypeError, ValueError):
        return False


def after_episode(remaining, confirm):
    if remaining > 1:
        return remaining - 1
    return CONTINUE_EPISODES if confirm() else 0


def next_episode(previous, episode_list, season_metadata):
    """Advance at most one episode, or to the first episode of the next season."""
    if not valid_episode(previous):
        return None
    season, episode = int(previous['season']), int(previous['episode'])
    candidate = next((item for item in episode_list(season)
                      if str(item.get('episode')) == str(episode + 1)), None)
    if candidate:
        return candidate
    numbers = [entry.get('episode_number') for entry in season_metadata(season).get('episodes', [])]
    if episode not in numbers or any(isinstance(number, int) and number > episode for number in numbers):
        return None
    return next((item for item in episode_list(season + 1)
                 if str(item.get('episode')) == '1'), None)
