"""Merged source selection and a real Kodi plugin playback handoff."""
import os,time
import xbmc,xbmcaddon,xbmcgui
import sourcejobs
WORKER=os.path.join(os.path.dirname(__file__),'sourceworker.py')
CANCELLED = object()

def launch(token):
    xbmc.executebuiltin('RunScript("'+WORKER+'",'+token+')')

def wait(base,tokens,title,current,log,timeout,allow_timeout=False):
    monitor=xbmc.Monitor();progress=xbmcgui.DialogProgress();progress.create(title,'Starting providers…')
    deadline=time.monotonic()+timeout
    try:
        while True:
            jobs=[sourcejobs.read(base,t) for t in tokens]
            if progress.iscanceled() or monitor.abortRequested() or not current():
                for token in tokens:sourcejobs.update(base,token,status='cancelled')
                return None
            if any(j and j['status']=='cancelled' for j in jobs):
                for token in tokens:sourcejobs.update(base,token,status='cancelled')
                return None
            jobs=[j or dict(provider='Unavailable provider',status='error',operation='collect',error='Source request expired or disappeared') for j in jobs]
            finished=sum(j['status'] in ('done','error') for j in jobs)
            progress.update(int(100*finished/max(1,len(tokens))), '\n'.join(
                j['provider']+': '+(str(len(j.get('sources',[])))+' sources' if j['status']=='done' and j['operation']=='collect' else j['status']) for j in jobs if j))
            if finished==len(tokens):return jobs
            if time.monotonic()>=deadline:
                for token,job in zip(tokens,jobs):
                    if job and job['status'] not in ('done','error','cancelled'):
                        sourcejobs.update(base,token,status='cancelled')
                        log('WARNING',job['provider']+' source request timed out')
                if allow_timeout:
                    return [job for job in jobs if job['status'] in ('done','error')]
                xbmcgui.Dialog().ok('Source search timed out','Not all providers have finished. The incomplete source list will not open. Try the search again or use Umbrella directly. Details are in MyFlix Log.')
                return None
            monitor.waitForAbort(.2)
    finally:progress.close()

def available_providers():
    return [(name, addon) for name, addon in sourcejobs.PROVIDERS.items()
            if xbmc.getCondVisibility('System.HasAddon('+addon+')')]


def start_collection(base, profile, item, name, addon, log):
    token = None
    try:
        account = xbmcaddon.Addon(addon)
        key = {'Umbrella':'realdebridtoken','POV':'rd.token'}[name]
        if not account.getSetting(key):
            log('WARNING',name+' has no Real-Debrid account linked. Link it once for all MyFlix profiles.')
        token = sourcejobs.create(base,profile,item,name)
        launch(token)
    except Exception as exc:
        error = sourcejobs.safe_label(exc)
        log('ERROR','Could not start '+name+' source search',error)
        if token:
            sourcejobs.update(base,token,status='error',error=error)
    return token


def collect_rows(jobs, combined):
    results = [(j['provider'],j.get('sources',[]),j.get('meta',{}))
               for j in jobs if j and j['status']=='done']
    if combined:
        return sourcejobs.merge(results)
    rows = [row for result in results for row in sourcejobs.merge([result])]
    return sorted(rows,key=lambda row:(not row['cached'],row['rank'],row['name'].lower()))


def choose(base,profile,item,current,log,download=False,automatic=False):
    providers = available_providers()
    if automatic:
        if not providers or not current():
            return None
        token = sourcejobs.create(base,profile,item,providers[0][0],'resolve')
        sourcejobs.update(base,token,automatic=True)
        return token
    tokens = [token for name, addon in providers
              for token in [start_collection(base,profile,item,name,addon,log)] if token]
    if not tokens:
        xbmcgui.Dialog().ok('Playback add-ons needed','Run MyFlix Installer → Install / repair MyFlix to install Umbrella and POV.');return False
    jobs=wait(base,tokens,'MyFlix · Searching Umbrella + POV',current,log,300)
    if jobs is None:return None
    merged=collect_rows(jobs, combined=download)
    if not current():return None
    errors=[j for j in jobs if j and j['status']=='error']
    for job in errors:log('ERROR',job['provider']+' source search failed',job.get('error',''))
    counts={j['provider']:len(j.get('sources',[])) for j in jobs if j and j['status']=='done'}
    for job in jobs:
        if job and job['status']=='done':log('INFO',job['provider']+' search finished: '+str(len(job.get('sources',[])))+' sources',str(job.get('diagnostics',{})))
    log('INFO','Combined source search completed',str(len(merged))+' unique sources; '+str(len(errors))+' provider errors')
    rows=[]
    for source in merged:
        label=source['quality']+' · '+('Cached' if source['cached'] else 'Cache unverified')+' · '+' + '.join(source['providers'])
        if source['size']:label+=' · '+format(source['size'],'.2f')+' GB'
        li=xbmcgui.ListItem(label=label,label2=source['name']);rows.append(li)
    if not download:
        rows.append(xbmcgui.ListItem(label='Open Umbrella’s original player',label2='Use the existing native playback option'))
    rows.append(xbmcgui.ListItem(label='Account Manager',label2='Shared Real-Debrid and Trakt setup'))
    while current():
        choice=xbmcgui.Dialog().select('MyFlix Sources · '+str(len(merged))+' results · '+', '.join(name+': '+str(counts.get(name,0)) for name in sourcejobs.PROVIDERS)+(' · provider errors in MyFlix Log' if errors else ''),rows,useDetails=True)
        if choice<0:return None
        if not download and choice==len(merged):return False
        if choice==len(rows)-1:
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.myflix/?mode=accountmanager)');return None
        selected=merged[choice]
        # Store raw URLs privately; the playback URL contains only this random job ID.
        token=sourcejobs.create(base,profile,item,selected['alternatives'][0]['provider'],'resolve')
        sourcejobs.update(base,token,alternatives=selected['alternatives'] if download else selected['alternatives'][:1])
        log('INFO','Selected combined source',selected['quality']+'; '+' + '.join(selected['providers']))
        return token
    return None

def playable_url(url):
    return isinstance(url,str) and url.startswith(('https://','http://'))


def resolve_alternative(base, job, alternative, current, log, automatic=False):
    if not current():
        return CANCELLED
    provider = alternative['provider']
    if provider not in sourcejobs.PROVIDERS:
        return None
    if provider=='POV' and playable_url(alternative['raw'].get('unrestricted_link')):
        return alternative['raw']['unrestricted_link']
    attempt=sourcejobs.create(base,job['profile'],job['item'],provider,'resolve',
                              alternative['raw'],alternative['meta'])
    launch(attempt)
    results=wait(base,[attempt],'MyFlix · Opening '+provider+' link',current,log,60 if automatic else 90,allow_timeout=automatic)
    if results is None:
        return CANCELLED
    result=results[0] if results else None
    url=result.get('url') if result and result['status']=='done' else None
    if playable_url(url):
        log('INFO','Source resolved',provider)
        return url
    log('ERROR','Selected source could not be resolved',provider+'; '+
        (result.get('error','No playable URL returned') if result else 'Source request timed out'))
    return None


def resolve_automatic(base, job, current, log):
    for provider, addon in available_providers():
        if not current():
            return CANCELLED
        token = start_collection(base,job['profile'],job['item'],provider,addon,log)
        if not token:
            continue
        jobs = wait(base,[token],'MyFlix · Searching '+provider,current,log,150,allow_timeout=True)
        if jobs is None:
            return CANCELLED
        rows = collect_rows(jobs, combined=False)
        for row in rows[:3]:
            url = resolve_alternative(base,job,row['alternatives'][0],current,log,automatic=True)
            if url is not None:
                return url
    return None


def resolve(base,token,current,log,download=False):
    job=sourcejobs.read(base,token)
    if not job:
        return None
    if job.get('automatic'):
        url=resolve_automatic(base,job,current,log)
    else:
        url = None
        alternatives = job.get('alternatives',[])
        for alternative in alternatives if download else alternatives[:1]:
            url=resolve_alternative(base,job,alternative,current,log)
            if url is not None:
                break
    if url is CANCELLED:
        return None
    if url:
        return url
    if download:
        xbmcgui.Dialog().ok('Download source unavailable','The selected source could not be resolved. Try another source.')
    elif job.get('automatic'):
        xbmcgui.Dialog().ok('Autoplay stopped','Umbrella and POV could not open a link for the next episode.')
    else:
        xbmcgui.Dialog().ok('Source did not play','The selected link could not be opened. Choose another link to try again.')
    return None
