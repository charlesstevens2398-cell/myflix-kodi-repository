"""Record only actual video playback in the active Kodi profile."""
import base64
import json
import os
import sys
import time
from collections import deque
from urllib.parse import urlencode
import xbmc
import xbmcgui
import xbmcvfs
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'resources'))
import core
import profiles
import controller
import eventlog
import autoplay
import sourcejobs
monitor=xbmc.Monitor()
playback_events=deque()
def playback_event(level,message):
    try:
        base=xbmcvfs.translatePath('special://profile/addon_data/plugin.video.myflix/')
        eventlog.add(os.path.join(base,'events.sqlite'),level,'MyFlix',message)
    except Exception:pass

class PlaybackMonitor(xbmc.Player):
    def onAVStarted(self):
        token = win.getProperty(autoplay.PLAYBACK_JOB)
        if token:
            win.clearProperty(autoplay.PLAYBACK_JOB)
        try:
            path = self.getPlayingFile() if token else ''
        except RuntimeError:
            path = ''
        playback_events.append(('started',token,path))
        playback_event('INFO','Video playback started')
    def onPlayBackEnded(self):
        playback_events.append(('ended','',''))
    def onPlayBackStopped(self):
        playback_events.append(('stopped','',''))
    def onPlayBackError(self):
        playback_events.append(('stopped','',''))
        playback_event('ERROR','Kodi reported a playback error')

player=PlaybackMonitor()
win=xbmcgui.Window(10000)
active=None
watched=0
position=total=0
profile=''
last_tick=time.monotonic()
last_log_read=0
autoplay_episode=None
finished_episode=None


def rpc_item():
    players=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Player.GetActivePlayers'}))).get('result',[])
    video=next((p for p in players if p.get('type')=='video'),None)
    if not video:return None
    result=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Player.GetItem','params':{'playerid':video['playerid'],'properties':['title','plot','art','uniqueid','season','episode','showtitle','year','mpaa']}}))).get('result',{}).get('item',{})
    ids=result.get('uniqueid',{})
    if not ids.get('tmdb') and not ids.get('imdb'):return None
    episode=core.normalize_episode(result).get('type')=='episode'
    result.update(tmdb=ids.get('tmdb',''),imdb=ids.get('imdb',''),series_tmdb=ids.get('tvshow.tmdb') or (ids.get('tmdb','') if episode else ''),path=result.get('file',''),title=result.get('title') or result.get('label',''),type='episode' if episode else 'movie')
    return result


def commit():
    if active and watched>=30:
        path=os.path.join(profile,'history.json')
        core.record_watch(path,active,watched,position,total)
        win.setProperty('MyFlix.StateRevision',str(time.time_ns()))
        if total and position/total>=0.9:
            marks=core.load(os.path.join(profile,'watched.json'),{})
            if not marks.get(core.key(active)):win.setProperty('MyFlix.StateRevision',str(time.time_ns()))
            if active.get('type')=='episode':core.set_episode_watched(marks,active,True)
            else:marks[core.key(active)]=True
            core.save(os.path.join(profile,'watched.json'),marks)
        if profile==profiles.directory(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.myflix/')):
            win.setProperty('MyFlix.HasHistory','true')
            history=core.load(path,[])
            normalized=[core.normalize_episode(i) for i in history]
            win.setProperty('MyFlix.HasMovieHistory','true' if any(i.get('type')=='movie' for i in normalized) else 'false')
            win.setProperty('MyFlix.HasShowHistory','true' if any(i.get('type') in ('tv','episode') for i in normalized) else 'false')
            win.setProperty('MyFlix.HasContinue','true' if any(not i.get('completed') and i.get('position',0)>0 for i in history) else 'false')
            try:
                detail=json.loads(base64.urlsafe_b64decode(win.getProperty('MyFlix.Detail')).decode())
                status=core.watch_status(detail,core.load(path,[]),core.load(os.path.join(profile,'watched.json'),{}))
                win.setProperty('MyFlix.Detail.watched',status)
                win.setProperty('MyFlix.Detail.watchLabel','Mark as unwatched' if status=='Watched' else 'Mark as watched')
            except (ValueError,TypeError):pass

while not monitor.abortRequested():
    controller.sync()
    if xbmc.getCondVisibility('Window.IsActive(Videos)') and win.getProperty('MyFlix.BrowseRevision')!=win.getProperty('MyFlix.StateRevision'):
        win.setProperty('MyFlix.BrowseRevision',win.getProperty('MyFlix.StateRevision'))
        xbmc.executebuiltin('Container.Refresh')
    if time.monotonic()-last_log_read>10:
        try:eventlog.ingest(os.path.join(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.myflix/'),'events.sqlite'),xbmcvfs.translatePath('special://logpath/kodi.log'))
        except Exception:pass
        last_log_read=time.monotonic()
    now=time.monotonic();delta=min(5,now-last_tick);last_tick=now
    current=profiles.directory(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.myflix/'))
    if profile and current!=profile:
        commit();active=None;watched=0;win.clearProperty('MyFlix.Pending')
        win.clearProperty('MyFlix.HasHistory');win.clearProperty('MyFlix.HasFavorites')
        win.clearProperty('MyFlix.Detail');win.clearProperty('MyFlix.Series')
    profile=current
    try:
        while playback_events:
            kind,token,path=playback_events.popleft()
            if kind=='started':
                finished_episode=None
                autoplay_episode=None
                if token and path:
                    base=xbmcvfs.translatePath('special://profile/addon_data/plugin.video.myflix/')
                    job=sourcejobs.read(base,token)
                    if (job and job.get('profile')==profile and job.get('autoplay_left') and
                            (job.get('playback_key')==autoplay.file_key(path) or
                             path=='plugin://plugin.video.myflix/?mode=combinedresolve&job='+token)):
                        autoplay_episode=job
            elif kind=='ended':
                if autoplay_episode is not None:
                    finished_episode=autoplay_episode
                autoplay_episode=None
            else:
                autoplay_episode=None
                finished_episode=None
                win.clearProperty(autoplay.PLAYBACK_JOB)
        playing=player.isPlayingVideo()
        if playing:
            position=player.getTime();total=player.getTotalTime()
            item=rpc_item()
            if active and item and core.key(item)!=core.key(active):
                commit();active=None;watched=0
            if active is None:
                pending=win.getProperty('MyFlix.Pending')
                if pending:
                    p=json.loads(base64.urlsafe_b64decode(pending).decode())
                    win.clearProperty('MyFlix.Pending')
                    if p.get('profile')==profile and time.time()-p.get('requested',0)<300:
                        active=dict(p,**(item or {}))
                        if not active.get('mpaa'):active['mpaa']=p.get('mpaa','')
                        if not active.get('series_tmdb'):active['series_tmdb']=p.get('series_tmdb','')
                if active is None:active=item
                if active and active.get('type')=='episode' and win.getProperty('MyFlix.Series'):
                    series=json.loads(base64.urlsafe_b64decode(win.getProperty('MyFlix.Series')).decode())
                    if series.get('profile')==profile and time.time()-series.get('requested',0)<3600:
                        if active.get('showtitle','').casefold()==series.get('title','').casefold():
                            active['series_tmdb']=series.get('tmdb','')
                            if not active.get('mpaa'):active['mpaa']=series.get('mpaa','')
                watched=0
            if active and not xbmc.getCondVisibility('Player.Paused'):
                watched+=delta
                if watched>=30 and int(watched)%10<3:commit()
        elif active:
            commit();active=None;watched=0;position=total=0
        if not player.isPlaying() and finished_episode is not None:
            job,finished_episode=finished_episode,None
            if job['profile']==profile and not monitor.abortRequested():
                item=base64.urlsafe_b64encode(json.dumps(job['item']).encode()).decode()
                query=urlencode(dict(mode='autonext',item=item,left=job['autoplay_left'],profile_dir=profile))
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.myflix/?'+query+')')
    except Exception as exc:
        xbmc.log('MyFlix history monitor: '+str(exc),xbmc.LOGDEBUG)
    monitor.waitForAbort(2)
commit()

win = None
player = None
monitor = None
