"""Short-lived private source jobs. Never place source URLs in GUI properties."""
import hashlib,json,os,sqlite3,time
PROVIDERS={'Umbrella':'plugin.video.umbrella','POV':'plugin.video.pov'}
TTL=900

def connect(base):
    os.makedirs(base,exist_ok=True)
    db=sqlite3.connect(os.path.join(base,'sources.sqlite'),timeout=15)
    db.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, expires REAL, data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS leases (provider TEXT PRIMARY KEY, job TEXT, expires REAL)')
    db.execute('DELETE FROM jobs WHERE expires < ?',(time.time(),));db.commit()
    return db

def create(base,profile,item,provider,operation='collect',source=None,meta=None):
    if provider not in PROVIDERS or operation not in ('collect','resolve'):raise ValueError('Invalid source job')
    data=dict(profile=profile,item=item,provider=provider,operation=operation,status='waiting',source=source,meta=meta)
    payload=json.dumps(data)
    # Include time/PID/retry salt as well as OS entropy for Kodi platforms with
    # repeated UUID values. Never replace another provider's existing request.
    for attempt in range(16):
        entropy=os.urandom(32)
        salt=('%s:%s:%s' % (time.time_ns(),os.getpid(),attempt)).encode()
        token=hashlib.sha256(entropy+salt).hexdigest()[:32]
        with connect(base) as db:
            cursor=db.execute('INSERT OR IGNORE INTO jobs VALUES (?,?,?)',(token,time.time()+TTL,payload))
            if cursor.rowcount==1:return token
    raise RuntimeError('Could not allocate a unique source request. Restart Kodi and retry.')

def prepare_item(item):
    """Keep series identity separate from the individual episode identity."""
    value=dict(item)
    if value.get('type')!='episode':return value
    parent=value.get('season_parent') or {}
    title=value.get('tvshowtitle') or value.get('showtitle') or parent.get('tvshowtitle') or parent.get('showtitle')
    show=value.get('series_tmdb') or parent.get('series_tmdb') or parent.get('tmdb')
    if title:value['tvshowtitle']=value['showtitle']=title
    if show:value['series_tmdb']=str(show)
    if value.get('show_year') or parent.get('year'):value['year']=value.get('show_year') or parent['year']
    return value

def read(base,token):
    if len(token)!=32 or any(c not in '0123456789abcdef' for c in token):return None
    with connect(base) as db:row=db.execute('SELECT data FROM jobs WHERE id=? AND expires>?',(token,time.time())).fetchone()
    return json.loads(row[0]) if row else None

def update(base,token,**changes):
    with connect(base) as db:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT data FROM jobs WHERE id=? AND expires>?',(token,time.time())).fetchone()
        if not row:return
        data=json.loads(row[0])
        if data['status']=='cancelled':return
        data.update(changes)
        db.execute('UPDATE jobs SET data=? WHERE id=?',(json.dumps(data),token))

def safe_label(value):
    import re
    value=re.sub(r'\[[^\]]*\]','',str(value or ''))
    value=re.sub(r'(?:https?://|magnet:)[^\s]+','[link hidden]',value)
    return value.replace('\n',' ')[:160]

def normalize(provider,raw,meta=None):
    import hashlib,re
    quality=str(raw.get('quality','SD')).upper().replace('2160P','4K')
    rank={'4K':0,'1080P':1,'720P':2,'SD':3}.get(quality,4)
    kind=str(raw.get('source','')).lower()
    if provider=='Umbrella':cached=kind.startswith('cached') or bool(raw.get('direct'))
    else:cached=bool(raw.get('unrestricted_link') or raw.get('cache_provider') or raw.get('cached')) and not any(k in str(raw.get('cache_provider','')).lower() for k in ('uncached','unchecked'))
    if 'uncached' in kind:cached=False
    name=safe_label(raw.get('name') or raw.get('display_name') or raw.get('release_title') or 'Unnamed source')
    hash_value=str(raw.get('hash','')).lower()
    if not hash_value:
        m=re.search(r'btih:([a-zA-Z0-9]+)',str(raw.get('url','')))
        if m:hash_value=m.group(1).lower()
    identity=(hash_value+'|'+str(raw.get('file_id') or raw.get('fileID') or '')) if hash_value else str(raw.get('url') or raw.get('unrestricted_link') or provider+name)
    key=hashlib.sha256(identity.encode()).hexdigest()
    try:size=float(raw.get('size') or 0)
    except (ValueError,TypeError):size=0
    return dict(key=key,name=name,quality=quality,cached=cached,rank=rank,size=size,providers=[provider],
                alternatives=[dict(provider=provider,raw=raw,meta=meta or {})])

def merge(results):
    groups={}
    for provider,items,meta in results:
        for raw in items:
            if not isinstance(raw,dict):continue
            row=normalize(provider,raw,meta)
            if row['key'] not in groups:groups[row['key']]=row;continue
            target=groups[row['key']]
            if provider not in target['providers']:target['providers'].append(provider)
            target['alternatives'].extend(row['alternatives'])
            target['cached']=target['cached'] or row['cached']
            if row['rank']<target['rank']:
                target['rank']=row['rank'];target['quality']=row['quality']
    return sorted(groups.values(),key=lambda r:(not r['cached'],r['rank'],r['name'].lower()))


def acquire(base,token,provider):
    with connect(base) as db:
        db.execute('BEGIN IMMEDIATE')
        db.execute('DELETE FROM leases WHERE expires < ?',(time.time(),))
        try:db.execute('INSERT INTO leases VALUES (?,?,?)',(provider,token,time.time()+TTL))
        except sqlite3.IntegrityError:return False
    return True

def release(base,token):
    with connect(base) as db:db.execute('DELETE FROM leases WHERE job=?',(token,))
