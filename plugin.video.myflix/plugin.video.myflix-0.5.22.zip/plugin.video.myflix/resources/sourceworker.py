"""One isolated Kodi script interpreter per provider; no third-party file patches."""
import json,os,sys,xml.etree.ElementTree as ET
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
sys.path.insert(0,os.path.dirname(__file__))
import sourcejobs

class QuietProgress:
    def __init__(self,*args,**kwargs):
        self.dialog_progress=None;self.full_screen=bool(args[0]) if args else False
    def create(self,*args,**kwargs):pass
    def make(self,*args,**kwargs):pass
    def update(self,*args,**kwargs):pass
    def close(self,*args,**kwargs):pass
    def kill(self,*args,**kwargs):pass
    def is_canceled(self):return self.iscanceled()
    def iscanceled(self):return xbmc.Monitor().abortRequested() or bool(_cancelled())

def _cancelled():
    row=sourcejobs.read(BASE,TOKEN)
    return not row or row['status']=='cancelled'

def native_paths(addon_id,seen=None):
    import addonpaths
    path=addonpaths.load(addon_id,ORIGINAL_ADDON,seen)
    if path:
        sys.path.insert(0,os.path.join(path,'resources','lib'));sys.path.insert(0,path)
    return path

def umbrella(job):
    from resources.lib.modules import control
    # Read Kodi's current settings rather than Umbrella's shared window cache:
    # Account Manager can update credentials without refreshing that cache.
    account=xbmcaddon.Addon('plugin.video.umbrella')
    def setting(key,fallback=None):
        value=account.getSetting(key)
        return fallback if value=='' and fallback is not None else value
    control.setting=setting
    from resources.lib.modules import sources,log_utils
    failures=[]
    native_error=log_utils.error
    def error(*args,**kwargs):
        exc=sys.exc_info()[1]
        if exc is not None:failures.append(type(exc).__name__)
        return native_error(*args,**kwargs)
    log_utils.error=error
    overrides={'preemptive.termination.movie':'false','preemptive.termination.tv':'false',
        'terminate.onCloud.sources':'false',
        'progress.dialog':'0','dialogs.useumbrelladialog':'false','custom.query':'false',
        'enable.playnext':'false','play.mode.tv':'0','play.mode.movie':'0'}
    sources.getSetting=lambda key,fallback=None:overrides[key] if key in overrides else setting(key,fallback)
    control.progressDialog=QuietProgress();control.progressDialogBG=QuietProgress()
    control.yesnoDialog=lambda *args,**kwargs:False
    control.cancelPlayback=lambda:None
    control.hide=lambda:None
    class Collector(sources.Sources):
        captured=None
        gathered=None
        def getSources(self,*args,**kwargs):
            result=super().getSources(*args,**kwargs)
            self.gathered=result
            return result
        def sourceSelect(self,title,items,uncached_items,meta):self.captured=(items,meta)
        def errorForSources(self,*args,**kwargs):self.captured=([],getattr(self,'meta',{}))
    item=sourcejobs.prepare_item(job['item']);meta=dict(job.get('meta') or item.get('source_meta') or item)
    episode=item.get('type')=='episode'
    if episode:
        showtitle=item.get('tvshowtitle') or meta.get('tvshowtitle') or meta.get('showtitle')
        if not showtitle:raise RuntimeError('Episode search is missing its series title. Reopen the series and season.')
        item['tvshowtitle']=showtitle
        meta.update(tvshowtitle=showtitle,showtitle=showtitle,mediatype='episode',season=item.get('season'),episode=item.get('episode'),tmdb=str(item.get('series_tmdb') or item.get('tmdb','')))
    else:meta['mediatype']='movie'
    control.playerWindow.clearProperty('umbrella.preResolved_nextUrl')
    src=Collector()
    if job['operation']=='resolve':
        src.meta=meta;src.title=meta.get('title','');src.season=meta.get('season');src.episode=meta.get('episode');src.mediatype=meta['mediatype']
        src.tvshowtitle=meta.get('tvshowtitle');src.imdb=item.get('imdb','');src.tmdb=str(item.get('series_tmdb') or item.get('tmdb',''));src.tvdb=str(item.get('tvdb') or '')
        src.prepareSources()
        control.homeWindow.setProperty(src.metaProperty,json.dumps(meta))
        return {'url':src.sourcesResolve(job['source'])}
    episode=item.get('type')=='episode'
    src.play(item.get('title',''),str(item.get('year') or ''),item.get('imdb',''),str(item.get('series_tmdb') or item.get('tmdb','')),
             str(item.get('tvdb') or ''),str(item.get('season',0)) if episode else None,
             str(item.get('episode',0)) if episode else None,item.get('tvshowtitle') if episode else None,
             item.get('premiered',''),json.dumps(meta),'0')
    if src.captured is None:raise RuntimeError('Umbrella stopped before returning sources; native errors: '+(', '.join(dict.fromkeys(failures)) or 'none captured'))
    if not src.captured[0] and src.gathered:raise RuntimeError('Umbrella gathered '+str(len(src.gathered))+' candidates, but its native final filters removed them. Check uncached-source settings in Umbrella.')
    if not src.captured[0] and failures:raise RuntimeError('Umbrella returned no sources after native errors: '+', '.join(dict.fromkeys(failures)))
    return dict(sources=src.captured[0],meta=src.captured[1],diagnostics=dict(returned=len(src.captured[0]),gathered=len(src.gathered) if isinstance(src.gathered,list) else 'native cache',external_enabled=setting('provider.external.enabled'),external_module=setting('external_provider.module'),account_linked=bool(setting('realdebridtoken')),native_errors=list(dict.fromkeys(failures))))

def pov(job):
    from modules import sources
    sources.DialogProgress=QuietProgress
    sources.hide_busy_dialog=lambda:None;sources.show_busy_dialog=lambda:None
    if job['operation']=='resolve':
        from modules.debrid import Source
        raw=job['source']
        return {'url':raw.get('unrestricted_link') or Source(raw,job.get('meta') or {}).resolve_sources()}
    item=sourcejobs.prepare_item(job['item']);params=dict(tmdb_id=str(item.get('series_tmdb') or item['tmdb']),background='true',autoplay='false')
    if item.get('type')=='episode':params.update(season=str(item['season']),episode=str(item['episode']))
    src=sources.Sources();src._clear_properties();src.config_loader.apply(src,params);src.meta=src.meta_builder.build(src)
    return dict(sources=src.get_sources() or [],meta=src.meta)

def main():
    global BASE,TOKEN,ORIGINAL_ADDON
    BASE=xbmcvfs.translatePath('special://profile/addon_data/plugin.video.myflix/')
    TOKEN=sys.argv[1] if len(sys.argv)>1 else ''
    job=sourcejobs.read(BASE,TOKEN)
    if not job or job['status']!='waiting':return
    if job['provider'] not in sourcejobs.PROVIDERS:
        sourcejobs.update(BASE,TOKEN,status='error',error='Provider is no longer available. Start a new search.')
        return
    ORIGINAL_ADDON=xbmcaddon.Addon
    target=sourcejobs.PROVIDERS[job['provider']]
    import time
    deadline=time.monotonic()+120
    while not sourcejobs.acquire(BASE,TOKEN,target):
        if _cancelled() or xbmc.Monitor().abortRequested():
            sourcejobs.update(BASE,TOKEN,status='cancelled');return
        if time.monotonic()>deadline:
            sourcejobs.update(BASE,TOKEN,status='error',error='Previous provider request is still finishing. Try again shortly.');return
        xbmc.Monitor().waitForAbort(.2)
    try:
        if _cancelled() or xbmc.Monitor().abortRequested():return
        sourcejobs.update(BASE,TOKEN,status='working')
        native_paths(target)
        # Addon() defaults to the scraper's settings inside this worker only.
        xbmcaddon.Addon=lambda id=None:ORIGINAL_ADDON(id or target)
        sys.argv=['plugin://'+target+'/', '-1', '']
        result=(umbrella if job['provider']=='Umbrella' else pov)(job)
        sourcejobs.update(BASE,TOKEN,status='done',**result)
    except (Exception,SystemExit) as exc:
        sourcejobs.update(BASE,TOKEN,status='error',error=type(exc).__name__+': '+sourcejobs.safe_label(exc))
    finally:
        sourcejobs.release(BASE,TOKEN)
        # Keep the default Addon bound while any native provider threads finish.
        # MyFlix explicitly disables interpreter reuse; this worker exits afterward.

if __name__=='__main__':main()
