import os, shutil

def repair(path):
    with open(path, encoding="utf-8") as handle:
        original = handle.read()
    marker = '# MyFlix device-code dialog repair v1'
    if marker in original:
        return
    start = original.index('\t\ttry:\n\t\t\tcontrol.progressDialog.create(control.lang(40055))')
    end = original.index('\n\t\tstart = time.time()', start)
    block = '''\t\t# MyFlix device-code dialog repair v1
\t\tmessage = control.progress_line % (
\t\t\tcontrol.lang(32513) % 'https://real-debrid.com/device',
\t\t\tcontrol.lang(32514) % user_code, '')
\t\tcontrol.progressDialog.create(control.lang(40055), message)
\t\tcontrol.progressDialog.update(0, message)
'''
    updated = original[:start] + block + original[end:]
    needle = '\t\t\tself.auth_loop()'
    if updated.count(needle) != 1:
        raise ValueError('Unsupported Account Manager authorization layout')
    updated = updated.replace(needle, '\t\t\tcontrol.progressDialog.update(min(99, int(100 * (time.time() - start) / timeout)), message)\n' + needle)
    compile(updated, path, 'exec')
    backup = path + '.myflix-original'
    if not os.path.exists(backup):
        shutil.copy2(path, backup)
    with open(path + '.myflix-new', 'w', encoding='utf-8', newline='\n') as handle:
        handle.write(updated)
    os.replace(path + '.myflix-new', path)
