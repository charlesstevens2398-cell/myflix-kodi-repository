"""Use the same external-provider module identifier as Umbrella's own selector."""
PROVIDER_ID='script.module.cocoscrapers'
PROVIDER_MODULE=PROVIDER_ID.rsplit('.',1)[-1]

def configure(umbrella,window,validate):
    validate(PROVIDER_ID,PROVIDER_MODULE)
    window.setProperty('umbrella.updateSettings','false')
    try:
        umbrella.setSetting('external_provider.name',PROVIDER_MODULE)
        umbrella.setSetting('external_provider.module',PROVIDER_ID)
        umbrella.setSetting('provider.external.enabled','true')
    finally:window.setProperty('umbrella.updateSettings','true')
