"""Single-ZIP setup. Native Kodi installs handle external dependencies."""
import json,os,sys,time,traceback
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
ROOT=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
sys.path.insert(0,os.path.join(ROOT,'resources'))

import providers
import accounts
MON=xbmc.Monitor()
PACKAGES=json.load(open(os.path.join(ROOT,'resources','manifest.json')))
PLAYBACK_ADDONS=[('plugin.video.umbrella','Umbrella'),('plugin.video.themoviedb.helper','TMDb Helper'),('script.module.jurialmunkey','jurialmunkey common'),('script.module.cocoscrapers','CocoScrapers'),('plugin.video.pov','POV'),('script.module.magneto','Magneto providers'),('script.module.acctvwr','Account Viewer'),('script.module.acctmgr','Account Manager'),('plugin.video.seren','Seren')]


def rpc(method,params):
    response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})))
    if 'error' in response:raise RuntimeError(response['error'].get('message','Kodi request failed'))
    return response.get('result',{})


def enabled(addon_id):
    try:return rpc('Addons.GetAddonDetails',{'addonid':addon_id,'properties':['enabled']}).get('addon',{}).get('enabled',False)
    except RuntimeError:return False


def enable(addon_id):
    rpc('Addons.SetAddonEnabled',{'addonid':addon_id,'enabled':True})
    if not enabled(addon_id):raise RuntimeError('Could not enable '+addon_id)


def validate_provider(addon_id,module):
    if not enabled(addon_id):
        raise RuntimeError('CocoScrapers is missing or disabled. Run Install / repair MyFlix first.')
    import importlib
    library=os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('path')),'lib')
    sys.path.insert(0,library)
    try:
        source_loader=getattr(importlib.import_module(module),'sources')
        if not callable(source_loader):raise TypeError('Provider sources is not callable')
    except Exception as exc:
        raise RuntimeError('CocoScrapers could not load: '+str(exc)+'. Update or reinstall CocoScrapers and restart Kodi.')
    finally:sys.path.remove(library)

def repair_providers():
    if not enabled('plugin.video.umbrella'):raise RuntimeError('Umbrella is missing or disabled. Run Install / repair MyFlix first.')
    providers.configure(xbmcaddon.Addon('plugin.video.umbrella'),xbmcgui.Window(10000),validate_provider)



class Setup:
    def __init__(self):
        self.dialog=xbmcgui.DialogProgress();self.dialog.create('MyFlix Setup','Preparing installation…')
        self.label='Preparing installation';self.account_repair_pending=False
        self.step=0;self.total=len(PACKAGES['packages'])+len(PLAYBACK_ADDONS)+3
    def update(self,label,fraction=0):
        self.label=label.split('\n',1)[0]
        if self.dialog.iscanceled() or MON.abortRequested():raise InterruptedError('Setup cancelled. Installed steps remain; run setup again to continue.')
        self.dialog.update(min(99,int(100*(self.step+fraction)/self.total)),label+'\nStep '+str(self.step+1)+' of '+str(self.total))
    def install_bundles(self):
        for item in PACKAGES['packages']:
            if not item['id'].startswith('repository.'):
                continue
            addon_id=item['id']
            self.update('Installing '+item['name']+' through Kodi')
            if not self.has_version(addon_id,'0'):
                xbmc.executebuiltin('InstallAddon('+addon_id+')',True)
            if not self.has_version(addon_id,'0'):
                raise RuntimeError(item['name']+' was not installed. Accept Kodi’s prompt and run setup again.')
            enable(addon_id)
            self.step+=1

        bundle_id='script.module.myflix.installset.progress'
        companion=[item for item in PACKAGES['packages'] if not item['id'].startswith('repository.')]
        missing=[item for item in companion if not self.has_version(item['id'],item['version'])]
        if missing:
            self.update('Installing the MyFlix skin and companion through Kodi')
            if not self.has_version(bundle_id,'1.0.0'):
                xbmc.executebuiltin('InstallAddon('+bundle_id+')',True)
            else:
                # A repair can restore a missing dependency while the installer module remains installed.
                for item in missing:
                    if not self.has_version(item['id'],'0'):
                        xbmc.executebuiltin('InstallAddon('+item['id']+')',True)
        for item in companion:
            if not self.has_version(item['id'],item['version']):
                raise RuntimeError(item['name']+' '+item['version']+' is required. Accept Kodi’s prompts and retry.')
            enable(item['id'])
            self.step+=1

    @staticmethod
    def has_version(addon_id, minimum):
        try:
            found=rpc('Addons.GetAddonDetails',{'addonid':addon_id,'properties':['version']}).get('addon',{})
        except RuntimeError:
            return False
        if not found.get('version'):
            return False
        def numeric(value):
            return tuple(int(part) for part in value.split('.') if part.isdigit())
        return numeric(found.get('version','0'))>=numeric(minimum)

    def native(self,addon_id,name):
        self.update('Installing '+name+'\nAccept Kodi’s installation prompts if shown.')
        if not enabled(addon_id):
            # InstallAddon opens Kodi’s real dependency/download progress dialog.
            xbmc.executebuiltin('InstallAddon('+addon_id+')',True)
        if addon_id=='plugin.video.seren':
            for _ in range(120):
                if enabled(addon_id):break
                self.update('Waiting for Seren and its dependencies')
                if MON.waitForAbort(.5):raise InterruptedError('Kodi is closing')
        if not enabled(addon_id):raise RuntimeError(name+' was not installed/enabled. Check internet access and its repository, then run setup again.')
        self.step+=1
    def seren_providers(self):
        self.update('Installing Seren provider package')
        companion=xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.myflix').getAddonInfo('path'))
        resource=os.path.join(companion,'resources')
        if resource not in sys.path:sys.path.insert(0,resource)
        import sourcejobs
        base=xbmcvfs.translatePath('special://profile/addon_data/plugin.video.myflix/')
        token=sourcejobs.create(base,'setup',{},'Seren','setup',meta={'archive':os.path.join(ROOT,'resources','a4kscrapers.zip')})
        xbmc.executebuiltin('RunScript("'+os.path.join(resource,'sourceworker.py')+'",'+token+')')
        deadline=time.monotonic()+180
        while time.monotonic()<deadline:
            self.update('Installing Seren provider package')
            job=sourcejobs.read(base,token)
            if job and job['status']=='done':self.step+=1;return
            if job and job['status']=='error':raise RuntimeError('Seren provider setup failed: '+job.get('error','Unknown error'))
            if MON.waitForAbort(.2):break
        sourcejobs.update(base,token,status='cancelled')
        raise RuntimeError('Seren provider setup did not finish. Run repair again after restarting Kodi.')
    def run(self):
        # Switch before replacing MyFlix files; keep its profiles/account data intact.
        if xbmc.getSkinDir()=='skin.myflix':
            self.update('Switching to Estuary for installation')
            self.dialog.close()
            rpc('Settings.SetSettingValue',{'setting':'lookandfeel.skin','value':'skin.estuary'})
            for _ in range(30):
                if xbmc.getSkinDir()!='skin.myflix':break
                if MON.waitForAbort(1):raise InterruptedError('Kodi is closing')
            if xbmc.getSkinDir()=='skin.myflix':raise RuntimeError('Switch to Estuary, then run the installer again.')
            self.dialog=xbmcgui.DialogProgress();self.dialog.create('MyFlix Setup','Continuing installation…')
        self.install_bundles()
        self.update('Refreshing add-on repositories')
        xbmc.executebuiltin('UpdateAddonRepos',True)
        self.step+=1
        # Repository updates are asynchronous; wait for actual repository-version results.
        for addon_id,name in PLAYBACK_ADDONS:
            try:
                rpc('Addons.GetAddonDetails',{'addonid':addon_id,'properties':['enabled']})
                enable(addon_id)
            except RuntimeError:pass
            deadline=time.monotonic()+120
            while not enabled(addon_id) and time.monotonic()<deadline:
                self.update('Refreshing repositories for '+name+'\nWaiting '+str(int(120-(deadline-time.monotonic())))+' seconds')
                available=rpc('Addons.GetAddons',{'installed':False,'properties':['name']}).get('addons',[])
                if any(a['addonid']==addon_id for a in available):break
                if MON.waitForAbort(2):raise InterruptedError('Kodi is closing')
            self.native(addon_id,name)
        self.seren_providers()
        self.update('Configuring Umbrella playback')
        repair_providers()
        self.update('Configuring TMDb Helper player')
        player_path=xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper/players/')
        os.makedirs(player_path,exist_ok=True)
        os.makedirs(os.path.join(os.path.dirname(player_path.rstrip("/\\")),"reconfigured_players"),exist_ok=True)
        player=json.load(open(os.path.join(ROOT,'resources','myflix.umbrella.json')))
        with open(os.path.join(player_path,'myflix.umbrella.json'),'w') as f:json.dump(player,f,indent=2)
        # A customised copy takes precedence over players/. Back it up before resetting
        # only the MyFlix-owned player, leaving all other customised players untouched.
        override=os.path.join(os.path.dirname(player_path.rstrip("/\\")),"reconfigured_players","myflix.umbrella.json")
        if os.path.exists(override):
            import shutil
            backup=xbmcvfs.translatePath('special://profile/addon_data/script.myflix.installer/backups/')
            os.makedirs(backup,exist_ok=True)
            shutil.copyfile(override,os.path.join(backup,'myflix.umbrella-'+str(time.time_ns())+'.json'))
            os.remove(override)
        helper=xbmcaddon.Addon('plugin.video.themoviedb.helper')
        helper.setSetting('default_player_movies','myflix.umbrella.json play_movie')
        helper.setSetting('default_player_episodes','myflix.umbrella.json play_episode')
        self.update('Configuring Account Manager')
        import accountauth
        auth_path=os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon('script.module.acctmgr').getAddonInfo('path')),'lib','acctmgr','modules','auth','realdebrid.py')
        try:
            accountauth.repair(auth_path)
        except PermissionError:
            self.account_repair_pending=True
            xbmc.log('MyFlix Account Manager dialog repair was blocked: '+traceback.format_exc(),xbmc.LOGWARNING)
        accounts.configure(xbmcvfs.translatePath('special://profile/addon_data/script.module.acctmgr/'))
        pov=xbmcaddon.Addon('plugin.video.pov')
        pov.setSetting('provider.external',pov.getSetting('provider.external') or 'true')
        self.step+=1
        self.dialog.update(100,'Setup complete. MyFlix, Umbrella, POV, Seren, TMDb Helper and Account Manager are installed.')
        self.dialog.close()
        message='Open Account Manager from MyFlix Settings to authorize Real-Debrid and Trakt. Restart Kodi after setup.'
        if self.account_repair_pending:
            message+='\nKodi denied access to the optional Account Manager dialog repair. Its installed authorization dialog remains in place.'
        xbmcgui.Dialog().ok('MyFlix installed',message)
        rpc('Settings.SetSettingValue',{'setting':'lookandfeel.skin','value':'skin.myflix'})


def main():
    choice=xbmcgui.Dialog().select('MyFlix Installer',['Install / repair MyFlix','Account Manager','Open MyFlix','Repair Umbrella external providers'])
    if choice<0:return
    if choice==0:
        setup=Setup()
        try:setup.run()
        except Exception as exc:
            setup.dialog.close();xbmc.log('MyFlix Installer · '+setup.label+'\n'+traceback.format_exc(),xbmc.LOGERROR)
            xbmcgui.Dialog().ok('MyFlix setup stopped',setup.label+'\n'+str(exc))
    elif choice==1:
        if enabled('script.module.acctmgr'):xbmc.executebuiltin('RunAddon(script.module.acctmgr)')
        else:xbmcgui.Dialog().ok('Install first','Run Install / repair MyFlix first.')
    elif choice==3:
        try:
            repair_providers()
            xbmcgui.Dialog().ok('Umbrella provider repaired','Provider settings were corrected. Restart Kodi before playback.')
        except Exception as exc:xbmcgui.Dialog().ok('Provider repair stopped',str(exc))
    else:
        if enabled('skin.myflix'):rpc('Settings.SetSettingValue',{'setting':'lookandfeel.skin','value':'skin.myflix'})
        else:xbmcgui.Dialog().ok('Install first','Run Install / repair MyFlix first.')

if __name__=='__main__':main()
