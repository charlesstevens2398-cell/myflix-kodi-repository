"""Prepare Account Manager's supported Trakt targets without touching tokens."""
import json,os,tempfile
TARGETS=['Umbrella','POV','Seren','TMDb Helper']
def configure(base):
    os.makedirs(base,exist_ok=True)
    path=os.path.join(base,'trakt_sync_list.json')
    data=json.load(open(path,encoding='utf-8')) if os.path.exists(path) else {'addon_list':[]}
    if not isinstance(data,dict) or not isinstance(data.get('addon_list'),list):raise ValueError('Account Manager Trakt selection is invalid; repair it in Account Manager.')
    data['addon_list']=list(dict.fromkeys(data['addon_list']+TARGETS))
    fd,tmp=tempfile.mkstemp(dir=base,prefix='myflix-sync-',suffix='.json')
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(data,f,indent=2)
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.remove(tmp)
